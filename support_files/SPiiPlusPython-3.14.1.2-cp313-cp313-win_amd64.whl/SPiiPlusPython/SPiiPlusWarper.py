##################################################################################################
##
# ACS Motion Control Ltd.
# Copyright © 1999 - 2024. All Rights Reserved.
##
# PROJECT			:    SPiiPlus
# SUBSYSTEM		:    SPiiPlus Python Package
# FILE				:	 SPiiPlusWarper.py
# VERSION			:    7.4.0.0
# OVERVIEW
# ========
##
# SPiiPlus Python Package export functions definition
##
##################################################################################################


# Generated at 27/05/2024 16:07:56


import sys
import SPiiPlusPython.SPiiPlusBinary as spb
from typing import Union
from SPiiPlusPython.SPiiPlusDefs.GlobalVariables import *
from SPiiPlusPython.SPiiPlusDefs.SPiiPlusStructsApi import *
from typing import Tuple, List, Set


def GetResult(hc, wait=None, timeout=0, shape=(-1, -1), struct_type=None):
	return spb.GetResult(hc, wait, timeout, shape, struct_type)


# The function return the version of the python package version
def GetPythonPackageVersion():
	return spb.GetPythonPackageVersion()


def OpenCommSerial(channel, rate):
	"""If you want to load ACSC.dll dynamically at runtime,
	define ACSC_RUNTIME_DYNAMIC_LINKING in your project before including this file
	Otherwise load-time dynamic linking is implied
	The function initiates communication via serial port"""
	return spb.OpenCommSerial(channel, rate)


def OpenCommEthernet(address, port):
	"""The function initiates communication via Ethernet"""
	return spb.OpenCommEthernet(address, port)


def OpenCommEthernetTCP(address, port):
	"""The function opens communication with the controller via Ethernet using TCP protocol."""
	return spb.OpenCommEthernetTCP(address, port)


def OpenCommEthernetUDP(address, port):
	"""The function opens communication with the controller via Ethernet using the UDP protocol."""
	return spb.OpenCommEthernetUDP(address, port)


def OpenCommDirect():
	"""The function initiates direct communication with simulator"""
	return spb.OpenCommDirect()


def GetEthernetCards(max=32, broadcastAddress=GeneralDefinition.ACSC_NONE, failure_check=False):
	"""The functions collects IP addresses of SPiiPlus cards connected to the local segment"""
	return spb.GetEthernetCards(max, broadcastAddress, failure_check)


def GetEthernetCardsExt(controllerInfoSize=sys.getsizeof(ACSC_CONTROLLER_INFO), max=32, broadcastAddress=GeneralDefinition.ACSC_NONE, failure_check=False):
	"""The functions collects IP addresses,serial number and part number of SPiiPlus cards connected to the local segment"""
	return spb.GetEthernetCardsExt(controllerInfoSize, max, broadcastAddress, failure_check)


def CloseComm(handle, failure_check=False):
	"""The function closes communication (for all kinds of communications)"""
	return spb.CloseComm(handle, failure_check)


def Send(handle, buf, count=None, wait=SYNCHRONOUS, failure_check=False):
	"""The function sends message"""
	return spb.Send(handle, buf, count, wait, failure_check)


def Receive(handle, count=256, wait=SYNCHRONOUS, failure_check=False):
	"""The function receives message"""
	return spb.Receive(handle, count, wait, failure_check)


def Transaction(handle, outBuf, outCount=None, inCount=256, wait=SYNCHRONOUS, failure_check=False):
	"""The function provides transaction: sends request and receives reply"""
	return spb.Transaction(handle, outBuf, outCount, inCount, wait, failure_check)


def Command(handle, outBuf, outCount=None, wait=SYNCHRONOUS, failure_check=False):
	"""The function sends a command to the controller and analyzes the controller response."""
	return spb.Command(handle, outBuf, outCount, wait, failure_check)


def WaitForAsyncCall(handle, buf, wait, timeout, failure_check=False):
	return spb.WaitForAsyncCall(handle, buf, wait, timeout, failure_check)


def CancelOperation(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function waits for completion of asynchronous call and retrieves a data.
	The function cancels any asynchronous (non-waiting) call"""
	return spb.CancelOperation(handle, wait, failure_check)


def GetLastError():
	"""The function retrieves the last error code
	function of the new library"""
	return spb.GetLastError()


def GetErrorString(handle, errorCode, count=256, failure_check=False):
	"""The function retrieves the explanation of an error code."""
	return spb.GetErrorString(handle, errorCode, count, failure_check)


def SetQueueOverflowTimeout(handle, timeout, failure_check=False):
	"""The function sets communication call delay"""
	return spb.SetQueueOverflowTimeout(handle, timeout, failure_check)


def GetQueueOverflowTimeout(handle, failure_check=False):
	"""The function retrieves communication call delay"""
	return spb.GetQueueOverflowTimeout(handle, failure_check)


def SetTimeout(handle, timeout, failure_check=False):
	"""The function sets communication timeout"""
	return spb.SetTimeout(handle, timeout, failure_check)


def GetTimeout(handle, failure_check=False):
	"""The function retrieves communication timeout"""
	return spb.GetTimeout(handle, failure_check)


def GetDefaultTimeout(handle, failure_check=False):
	"""The function retrieves default communication timeout"""
	return spb.GetDefaultTimeout(handle, failure_check)


def SetIterations(handle, iterations, failure_check=False):
	"""The function sets the number of iterations of one transaction"""
	return spb.SetIterations(handle, iterations, failure_check)


def SetCommOptions(handle, options, failure_check=False):
	"""The function sets communication options"""
	return spb.SetCommOptions(handle, options, failure_check)


def GetCommOptions(handle, failure_check=False):
	"""The function retrieves communication options"""
	return spb.GetCommOptions(handle, failure_check)


def ClearBreakpoints(handle, buffer, line, wait=SYNCHRONOUS, failure_check=False):
	"""The function Clears breakpoints"""
	return spb.ClearBreakpoints(handle, buffer, line, wait, failure_check)


def SetBreakpoint(handle, buffer, line, wait=SYNCHRONOUS, failure_check=False):
	"""The function Sets a breakpoint"""
	return spb.SetBreakpoint(handle, buffer, line, wait, failure_check)


def GetBreakpointsList(handle, buffer, arraySize=64, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves breakpoints of a buffer"""
	return spb.GetBreakpointsList(handle, buffer, arraySize, wait, failure_check)


def GetLibraryVersion():
	"""The function retrieves ACSC Library version"""
	return spb.GetLibraryVersion()


def LoadBuffer(handle, buffer, text, count=None, wait=SYNCHRONOUS, failure_check=False):
	"""The function loads ACSPL+ program to the specified program buffer."""
	return spb.LoadBuffer(handle, buffer, text, count, wait, failure_check)


def LoadBufferIgnoreServiceLines(handle, buffer, text, count=None, wait=SYNCHRONOUS, failure_check=False):
	"""The function loads ACSPL+ program to the specified program buffer.
	Service lines are ignored."""
	return spb.LoadBufferIgnoreServiceLines(handle, buffer, text, count, wait, failure_check)


def LoadBuffersFromFile(handle, filename, wait=SYNCHRONOUS, failure_check=False):
	"""The function loads ACSPL+ programs to the specified program buffers.
	From *.prg file"""
	return spb.LoadBuffersFromFile(handle, filename, wait, failure_check)


def AppendBuffer(handle, buffer, text, count=None, wait=SYNCHRONOUS, failure_check=False):
	"""The function appends one or more ACSPL+ lines to the program in the specified program buffer."""
	return spb.AppendBuffer(handle, buffer, text, count, wait, failure_check)


def DownloadBuffer(handle, buffer, text, count=None, wait=SYNCHRONOUS, failure_check=False):
	"""The function downloads text to a program buffer. The function is similar to the function AppendBuffer()"""
	return spb.DownloadBuffer(handle, buffer, text, count, wait, failure_check)


def UploadBuffer(handle, buffer, offset, count=256, wait=SYNCHRONOUS, failure_check=False):
	"""The function uploads text from a program buffer"""
	return spb.UploadBuffer(handle, buffer, offset, count, wait, failure_check)


def ClearBuffer(handle, buffer, fromLine, toLine, wait=SYNCHRONOUS, failure_check=False):
	"""The function deletes the specified ACSPL+ program lines in the specified program buffer."""
	return spb.ClearBuffer(handle, buffer, fromLine, toLine, wait, failure_check)


def CompileBuffer(handle, buffer, wait=SYNCHRONOUS, failure_check=False):
	"""The function compiles ACSPL+ program in the specified program buffer(s)."""
	return spb.CompileBuffer(handle, buffer, wait, failure_check)


def RunBuffer(handle, buffer, label, wait=SYNCHRONOUS, failure_check=False):
	"""The function starts up ACSPL+ program in the specified program buffer."""
	return spb.RunBuffer(handle, buffer, label, wait, failure_check)


def StopBuffer(handle, buffer, wait=SYNCHRONOUS, failure_check=False):
	"""The function stops ACSPL+ program in the specified program buffer(s)."""
	return spb.StopBuffer(handle, buffer, wait, failure_check)


def SuspendBuffer(handle, buffer, wait=SYNCHRONOUS, failure_check=False):
	"""The function suspends ACSPL+ program in the specified program buffer(s)."""
	return spb.SuspendBuffer(handle, buffer, wait, failure_check)


def ReadInteger(handle, nBuf, var, from1, to1, from2, to2, wait=SYNCHRONOUS, failure_check=False):
	"""The function reads value(s) from integer variable"""
	return spb.ReadInteger(handle, nBuf, var, from1, to1, from2, to2, wait, failure_check)


def WriteInteger(handle, nBuf, var, from1, to1, from2, to2, values, wait=SYNCHRONOUS, failure_check=False):
	"""The function writes value(s) to integer variable"""
	return spb.WriteInteger(handle, nBuf, var, from1, to1, from2, to2, values, wait, failure_check)


def ReadReal(handle, nBuf, var, from1, to1, from2, to2, wait=SYNCHRONOUS, failure_check=False):
	"""The function reads value(s) from real variable"""
	return spb.ReadReal(handle, nBuf, var, from1, to1, from2, to2, wait, failure_check)


def WriteReal(handle, nBuf, var, from1, to1, from2, to2, values, wait=SYNCHRONOUS, failure_check=False):
	"""The function writes value(s) to real variable"""
	return spb.WriteReal(handle, nBuf, var, from1, to1, from2, to2, values, wait, failure_check)


def ReadString(handle, nBuf, var, from1, to1, from2, to2, stringSize, wait=SYNCHRONOUS, failure_check=False):
	"""The function reads value(s) from String variable"""
	return spb.ReadString(handle, nBuf, var, from1, to1, from2, to2, stringSize, wait, failure_check)


def WriteString(handle, nBuf, var, from1, to1, from2, to2, strings, stringSize=64, wait=SYNCHRONOUS, failure_check=False):
	"""The function writes value(s) to String variable"""
	return spb.WriteString(handle, nBuf, var, from1, to1, from2, to2, strings, stringSize, wait, failure_check)


def ReadStruct(handle, nBuf, var, from_par, to, struct_type, wait, failure_check=False):
	return spb.ReadStruct(handle, nBuf, var, from_par, to, struct_type, wait, failure_check)


def WriteStruct(handle, nBuf, var, from_par, to, values, valuesSize, wait, failure_check=False):
	return spb.WriteStruct(handle, nBuf, var, from_par, to, values, valuesSize, wait, failure_check)


def CaptureComm(handle, failure_check=False):
	"""The function reads value(s) from Struct variable
	The function writes value(s) to Struct variable
	The function captures communication"""
	return spb.CaptureComm(handle, failure_check)


def ReleaseComm(handle, failure_check=False):
	"""The function releases communication"""
	return spb.ReleaseComm(handle, failure_check)


def OpenHistoryBuffer(handle, size):
	"""The function initiates history buffer"""
	return spb.OpenHistoryBuffer(handle, size)


def CloseHistoryBuffer(handle, failure_check=False):
	"""The function closes history buffer"""
	return spb.CloseHistoryBuffer(handle, failure_check)


def GetHistory(handle, count=256, bClear=True, failure_check=False):
	"""The function retrieves the contents of the history buffer"""
	return spb.GetHistory(handle, count, bClear, failure_check)


def OpenMessageBuffer(handle, size):
	"""The function initiates unsolicited messages buffer"""
	return spb.OpenMessageBuffer(handle, size)


def CloseMessageBuffer(handle, failure_check=False):
	"""The function closes unsolicited messages buffer"""
	return spb.CloseMessageBuffer(handle, failure_check)


def GetMessage(handle, count=256, bClear=True, failure_check=False):
	"""The function retrieves all stored unsolicited messages from buffer"""
	return spb.GetMessage(handle, count, bClear, failure_check)


def GetSingleMessage(handle, count=256, timeout=2000, failure_check=False):
	"""The function retrieves a single unsolicited message or exits by timeout"""
	return spb.GetSingleMessage(handle, count, timeout, failure_check)


def OpenLogFile(handle, fileName, failure_check=False):
	"""The function opens a log file."""
	return spb.OpenLogFile(handle, fileName, failure_check)


def OpenSCLogFile(handle, fileName, failure_check=False):
	"""The function opens the SPiiPlusSC log file."""
	return spb.OpenSCLogFile(handle, fileName, failure_check)


def CloseLogFile(handle, failure_check=False):
	"""The function closes logfile."""
	return spb.CloseLogFile(handle, failure_check)


def CloseSCLogFile(handle, failure_check=False):
	"""The function closes the SPiiPlusSC log file."""
	return spb.CloseSCLogFile(handle, failure_check)


def WriteLogFile(handle, buf, count=None, failure_check=False):
	"""The function writes to logfile."""
	return spb.WriteLogFile(handle, buf, count, failure_check)


def WriteSCLogFile(handle, buf, count=None, failure_check=False):
	"""The function writes to the SPiiPlusSC log file."""
	return spb.WriteSCLogFile(handle, buf, count, failure_check)


def FlushLogFile(filename, failure_check=False):
	"""This function allows flushing the SPiiPlus UMD (User Mode Driver) internal binary buffer to a
	specified text file from the C Library application."""
	return spb.FlushLogFile(filename, failure_check)


def FlushSCLogFile(filename, bClear, failure_check=False):
	"""The function enables flushing the SPiiPlusSC internal binary buffer to a specified text file from the C
	Library application."""
	return spb.FlushSCLogFile(filename, bClear, failure_check)


def GetLogData(handle, count=256, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the data of firmware log"""
	return spb.GetLogData(handle, count, wait, failure_check)


def SetVelocity(handle, axis, velocity, wait=SYNCHRONOUS, failure_check=False):
	"""The function defines a value of motion velocity."""
	return spb.SetVelocity(handle, axis, velocity, wait, failure_check)


def GetVelocity(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves a value of motion velocity."""
	return spb.GetVelocity(handle, axis, wait, failure_check)


def SetAcceleration(handle, axis, acceleration, wait=SYNCHRONOUS, failure_check=False):
	"""The function defines a value of motion acceleration."""
	return spb.SetAcceleration(handle, axis, acceleration, wait, failure_check)


def GetAcceleration(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves a value of motion acceleration."""
	return spb.GetAcceleration(handle, axis, wait, failure_check)


def SetDeceleration(handle, axis, deceleration, wait=SYNCHRONOUS, failure_check=False):
	"""The function defines a value of motion deceleration."""
	return spb.SetDeceleration(handle, axis, deceleration, wait, failure_check)


def GetDeceleration(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves a value of motion deceleration."""
	return spb.GetDeceleration(handle, axis, wait, failure_check)


def SetJerk(handle, axis, jerk, wait=SYNCHRONOUS, failure_check=False):
	"""The function defines a value of motion jerk."""
	return spb.SetJerk(handle, axis, jerk, wait, failure_check)


def GetJerk(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves a value of motion jerk."""
	return spb.GetJerk(handle, axis, wait, failure_check)


def SetKillDeceleration(handle, axis, killDeceleration, wait=SYNCHRONOUS, failure_check=False):
	"""The function defines a value of kill deceleration."""
	return spb.SetKillDeceleration(handle, axis, killDeceleration, wait, failure_check)


def GetKillDeceleration(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves a value of kill deceleration."""
	return spb.GetKillDeceleration(handle, axis, wait, failure_check)


def SetVelocityImm(handle, axis, velocity, wait=SYNCHRONOUS, failure_check=False):
	"""The function provides on-the-fly change a value of motion velocity."""
	return spb.SetVelocityImm(handle, axis, velocity, wait, failure_check)


def SetAccelerationImm(handle, axis, acceleration, wait=SYNCHRONOUS, failure_check=False):
	"""The function provides on-the-fly change a value of motion acceleration."""
	return spb.SetAccelerationImm(handle, axis, acceleration, wait, failure_check)


def SetDecelerationImm(handle, axis, deceleration, wait=SYNCHRONOUS, failure_check=False):
	"""The function provides on-the-fly change a value of motion deceleration."""
	return spb.SetDecelerationImm(handle, axis, deceleration, wait, failure_check)


def SetJerkImm(handle, axis, jerk, wait=SYNCHRONOUS, failure_check=False):
	"""The function provides on-the-fly change a value of motion jerk."""
	return spb.SetJerkImm(handle, axis, jerk, wait, failure_check)


def SetKillDecelerationImm(handle, axis, killDeceleration, wait=SYNCHRONOUS, failure_check=False):
	"""The function provides on-the-fly change a value of kill deceleration."""
	return spb.SetKillDecelerationImm(handle, axis, killDeceleration, wait, failure_check)


def SetTargetPositionM(handle, axes, targetPositions, wait=SYNCHRONOUS, failure_check=False):
	"""The function assigns a current value of target position for several axes."""
	return spb.SetTargetPositionM(handle, axes, targetPositions, wait, failure_check)


def SetTargetPosition(handle, axis, targetPosition, wait=SYNCHRONOUS, failure_check=False):
	"""The function assigns a current value of target position."""
	return spb.SetTargetPosition(handle, axis, targetPosition, wait, failure_check)


def GetTargetPosition(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves a current value of motor feedback position."""
	return spb.GetTargetPosition(handle, axis, wait, failure_check)


def SetFPosition(handle, axis, fPosition, wait=SYNCHRONOUS, failure_check=False):
	"""The function assigns a current value of target position."""
	return spb.SetFPosition(handle, axis, fPosition, wait, failure_check)


def GetFPosition(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves a current value of motor feedback position."""
	return spb.GetFPosition(handle, axis, wait, failure_check)


def SetRPosition(handle, axis, rPosition, wait=SYNCHRONOUS, failure_check=False):
	"""The function assigns a current value of reference position."""
	return spb.SetRPosition(handle, axis, rPosition, wait, failure_check)


def GetRPosition(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves a current value of reference position."""
	return spb.GetRPosition(handle, axis, wait, failure_check)


def GetFVelocity(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves a current value of motor feedback velocity."""
	return spb.GetFVelocity(handle, axis, wait, failure_check)


def GetRVelocity(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves a current value of reference velocity."""
	return spb.GetRVelocity(handle, axis, wait, failure_check)


def Enable(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function activates a motor."""
	return spb.Enable(handle, axis, wait, failure_check)


def EnableM(handle, axes, wait=SYNCHRONOUS, failure_check=False):
	"""The function activates several motors."""
	return spb.EnableM(handle, axes, wait, failure_check)


def Disable(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function shuts off a motor."""
	return spb.Disable(handle, axis, wait, failure_check)


def DisableM(handle, axes, wait=SYNCHRONOUS, failure_check=False):
	"""The function shuts off several motors."""
	return spb.DisableM(handle, axes, wait, failure_check)


def DisableAll(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function shuts off all motors."""
	return spb.DisableAll(handle, wait, failure_check)


def Commut(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function performs commutation to brushless motor."""
	return spb.Commut(handle, axis, wait, failure_check)


def CommutExt(handle, axis, current, settle, slope, wait=SYNCHRONOUS, failure_check=False):
	"""The function performs commutation to brushless motor. Extended parameters"""
	return spb.CommutExt(handle, axis, current, settle, slope, wait, failure_check)


def Group(handle, axes, wait=SYNCHRONOUS, failure_check=False):
	"""The function creates a coordinate system for multi-axis motion."""
	return spb.Group(handle, axes, wait, failure_check)


def Split(handle, axes, wait=SYNCHRONOUS, failure_check=False):
	"""The function breaks down an axis group created before by the Group function."""
	return spb.Split(handle, axes, wait, failure_check)


def SplitAll(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function breaks down all axis groups created before by the Group function."""
	return spb.SplitAll(handle, wait, failure_check)


def Go(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function starts up a motion that is waiting in the specified motion queue."""
	return spb.Go(handle, axis, wait, failure_check)


def GoM(handle, axes, wait=SYNCHRONOUS, failure_check=False):
	"""The function synchronously starts up several motions
	that are waiting in the specified motion queues."""
	return spb.GoM(handle, axes, wait, failure_check)


def Halt(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function terminates a motion using the full deceleration profile."""
	return spb.Halt(handle, axis, wait, failure_check)


def HaltM(handle, axes, wait=SYNCHRONOUS, failure_check=False):
	"""The function terminates several motions using the full deceleration profile."""
	return spb.HaltM(handle, axes, wait, failure_check)


def Kill(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function terminates a motion using reduced deceleration profile."""
	return spb.Kill(handle, axis, wait, failure_check)


def KillM(handle, axes, wait=SYNCHRONOUS, failure_check=False):
	"""The function terminates several motions using reduced deceleration profile."""
	return spb.KillM(handle, axes, wait, failure_check)


def KillAll(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function terminates all currently executed motions."""
	return spb.KillAll(handle, wait, failure_check)


def Break(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function terminates a motion immediately and
	provides a smooth transition to the next motion."""
	return spb.Break(handle, axis, wait, failure_check)


def BreakM(handle, axes, wait=SYNCHRONOUS, failure_check=False):
	"""The function terminates several motions immediately and
	provides a smooth transition to the next motions."""
	return spb.BreakM(handle, axes, wait, failure_check)


def ToPoint(handle, flags, axis, point, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a single-axis motion to the specified point."""
	return spb.ToPoint(handle, flags, axis, point, wait, failure_check)


def ToPointM(handle, flags, axes, point, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a multi-axis motion to the specified point"""
	return spb.ToPointM(handle, flags, axes, point, wait, failure_check)


def ExtToPoint(handle, flags, axis, point, velocity, endVelocity, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a single-axis motion to the specified point
	using the specified velocity or end velocity."""
	return spb.ExtToPoint(handle, flags, axis, point, velocity, endVelocity, wait, failure_check)


def ExtToPointM(handle, flags, axes, point, velocity, endVelocity, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a multi-axis motion to the specified point
	using the specified velocity or end velocity."""
	return spb.ExtToPointM(handle, flags, axes, point, velocity, endVelocity, wait, failure_check)


def Track(handle, flags, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a single-axis track motion."""
	return spb.Track(handle, flags, axis, wait, failure_check)


def TrackM(handle, flags, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a multile-axis track motion."""
	return spb.TrackM(handle, flags, axis, wait, failure_check)


def FaultClear(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function clears the current faults and results of previous faults stored in the MERR variable.
	For single axis"""
	return spb.FaultClear(handle, axis, wait, failure_check)


def FaultClearM(handle, axes, wait=SYNCHRONOUS, failure_check=False):
	"""The function clears the current faults and results of previous faults stored in the MERR variable.
	For multiple axes"""
	return spb.FaultClearM(handle, axes, wait, failure_check)


def GetAxesCount(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function reads number of available axes"""
	return spb.GetAxesCount(handle, wait, failure_check)


def GetBuffersCount(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function reads number of available ACSPL+ programming buffers"""
	return spb.GetBuffersCount(handle, wait, failure_check)


def GetDBufferIndex(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function reads index of D-Buffer"""
	return spb.GetDBufferIndex(handle, wait, failure_check)


def SysInfo(handle, key, wait=SYNCHRONOUS, failure_check=False):
	"""The function reads system information"""
	return spb.SysInfo(handle, key, wait, failure_check)


def SetConf(handle, key, index, value, wait=SYNCHRONOUS, failure_check=False):
	"""The function writes system configuration"""
	return spb.SetConf(handle, key, index, value, wait, failure_check)


def GetConf(handle, key, index, wait=SYNCHRONOUS, failure_check=False):
	"""The function reads system configuration"""
	return spb.GetConf(handle, key, index, wait, failure_check)


def Jog(handle, flags, axis, velocity, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a single-axis jog motion."""
	return spb.Jog(handle, flags, axis, velocity, wait, failure_check)


def JogM(handle, flags, axes, direction, velocity, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a multi-axis jog motion."""
	return spb.JogM(handle, flags, axes, direction, velocity, wait, failure_check)


def SetMaster(handle, axis, formula, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates calculating of master value for an axis."""
	return spb.SetMaster(handle, axis, formula, wait, failure_check)


def Slave(handle, flags, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a master-slave motion."""
	return spb.Slave(handle, flags, axis, wait, failure_check)


def SlaveStalled(handle, flags, axis, left, right, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a master-slave motion with a limited following area."""
	return spb.SlaveStalled(handle, flags, axis, left, right, wait, failure_check)


def MultiPoint(handle, flags, axis, dwell, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a single-axis multi-point motion."""
	return spb.MultiPoint(handle, flags, axis, dwell, wait, failure_check)


def MultiPointM(handle, flags, axes, dwell, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a multi-axis multi-point motion."""
	return spb.MultiPointM(handle, flags, axes, dwell, wait, failure_check)


def BoostedPointToPointMotion(handle, flags, axes, point, velocity, finalVelocity, time, fixedTime, motionDelay, wait=SYNCHRONOUS, failure_check=False):
	"""The function defines a motion profile using the MotionBoost Feature."""
	return spb.BoostedPointToPointMotion(handle, flags, axes, point, velocity, finalVelocity, time, fixedTime, motionDelay, wait, failure_check)


def SmoothPointToPointMotion(handle, flags, axes, point, velocity, wait=SYNCHRONOUS, failure_check=False):
	"""The function provides for positioning to specific target,
	The motion profile is optimized to pass on a rounded path near the breaking point, minimizing changes in speedand direction that would cause unwanted vibrations in the system."""
	return spb.SmoothPointToPointMotion(handle, flags, axes, point, velocity, wait, failure_check)


def SmoothTransitionPointToPointMotion(handle, flags, axes, point, velocity, motionDelay, wait=SYNCHRONOUS, failure_check=False):
	"""If the axis is moving when the command is issued, the controller creates the motion and inserts it into the axis motion queue.
	The motion waits in the queue until all motions before it finish, and only then starts."""
	return spb.SmoothTransitionPointToPointMotion(handle, flags, axes, point, velocity, motionDelay, wait, failure_check)


def Spline(handle, flags, axis, period, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a single-axis spline motion.
	The motion follows an arbitrary path defined by a set of points."""
	return spb.Spline(handle, flags, axis, period, wait, failure_check)


def SplineM(handle, flags, axes, period, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a multi-axis spline motion.
	The motion follows an arbitrary path defined by a set of points."""
	return spb.SplineM(handle, flags, axes, period, wait, failure_check)


def Segment(handle, flags, axes, point, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a multi-axis segmented motion."""
	return spb.Segment(handle, flags, axes, point, wait, failure_check)


def SegmentedMotion(handle, flags, axes, point, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a multi-axis segmented motion."""
	return spb.SegmentedMotion(handle, flags, axes, point, wait, failure_check)


def ExtendedSegmentedMotion(handle, flags, axes, point, velocity, endVelocity, junctionVelocity, angle, starvationMargin, segments, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a multi-axis extended segmented motion."""
	return spb.ExtendedSegmentedMotion(handle, flags, axes, point, velocity, endVelocity, junctionVelocity, angle, starvationMargin, segments, wait, failure_check)


def ExtendedSegmentedMotionExt(handle, flags, axes, point, velocity, endVelocity, junctionVelocity, angle, curveVelocity, deviation, radius, maxLength, starvationMargin, segments, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a multi-axis extended segmented motion."""
	return spb.ExtendedSegmentedMotionExt(handle, flags, axes, point, velocity, endVelocity, junctionVelocity, angle, curveVelocity, deviation, radius, maxLength, starvationMargin, segments, wait, failure_check)


def ExtendedSegmentedMotionV2(handle, flags, axes, point, velocity, endVelocity, junctionVelocity, angle, curveVelocity, deviation, radius, maxLength, starvationMargin, segments, extLoopType, minSegmentLength, maxAllowedDeviation, outputIndex, bitNumber, polarity, motionDelay, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a multi-axis extended segmented motion."""
	return spb.ExtendedSegmentedMotionV2(handle, flags, axes, point, velocity, endVelocity, junctionVelocity, angle, curveVelocity, deviation, radius, maxLength, starvationMargin, segments, extLoopType, minSegmentLength, maxAllowedDeviation, outputIndex, bitNumber, polarity, motionDelay, wait, failure_check)


def BlendedSegmentMotion(handle, flags, axes, point, segmentTime, accelerationTime, jerkTime, dwellTime, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates a multi-axis blended segmented motion."""
	return spb.BlendedSegmentMotion(handle, flags, axes, point, segmentTime, accelerationTime, jerkTime, dwellTime, wait, failure_check)


def BlendedLine(handle, flags, axes, point, segmentTime, accelerationTime, jerkTime, dwellTime, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a linear segment to a blended segmented motion"""
	return spb.BlendedLine(handle, flags, axes, point, segmentTime, accelerationTime, jerkTime, dwellTime, wait, failure_check)


def BlendedArc1(handle, flags, axes, center, finalPoint, rotation, segmentTime, accelerationTime, jerkTime, dwellTime, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, coordinates of the final point and the direction of rotation."""
	return spb.BlendedArc1(handle, flags, axes, center, finalPoint, rotation, segmentTime, accelerationTime, jerkTime, dwellTime, wait, failure_check)


def BlendedArc2(handle, flags, axes, center, angle, segmentTime, accelerationTime, jerkTime, dwellTime, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, rotation angle"""
	return spb.BlendedArc2(handle, flags, axes, center, angle, segmentTime, accelerationTime, jerkTime, dwellTime, wait, failure_check)


def Line(handle, axes, point, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a linear segment to a segmented motion."""
	return spb.Line(handle, axes, point, wait, failure_check)


def ExtLine(handle, axes, point, velocity, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a linear segment to a segmented motion and specifies a motion velocity."""
	return spb.ExtLine(handle, axes, point, velocity, wait, failure_check)


def SegmentLineExt(handle, flags, axes, point, velocity, endVelocity, time, values, variables, index, masks, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a linear segment to a segmented motion
	Specifies motion velocity, end motion velocity, and user variables parameters"""
	return spb.SegmentLineExt(handle, flags, axes, point, velocity, endVelocity, time, values, variables, index, masks, wait, failure_check)


def SegmentLineV2(handle, flags, axes, point, velocity, endVelocity, time, values, variables, index, masks, extLoopType, minSegmentLength, maxAllowedDeviation, lciState, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a linear segment to a segmented motion
	Specifies motion velocity, end motion velocity, and user variables parameters"""
	return spb.SegmentLineV2(handle, flags, axes, point, velocity, endVelocity, time, values, variables, index, masks, extLoopType, minSegmentLength, maxAllowedDeviation, lciState, wait, failure_check)


def Arc1(handle, axes, center, finalPoint, rotation, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, coordinates of the final point and the direction of rotation."""
	return spb.Arc1(handle, axes, center, finalPoint, rotation, wait, failure_check)


def ExtArc1(handle, axes, center, finalPoint, rotation, velocity, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, coordinates of the final point, direction of rotation and
	the vector velocity for the current segment."""
	return spb.ExtArc1(handle, axes, center, finalPoint, rotation, velocity, wait, failure_check)


def SegmentArc1(handle, flags, axes, center, finalPoint, rotation, velocity, endVelocity, values, variables, index, masks, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, coordinates of the final point, direction of rotation, vector velocity,
	end motion velocity, and user variables parameters for the current segment."""
	return spb.SegmentArc1(handle, flags, axes, center, finalPoint, rotation, velocity, endVelocity, values, variables, index, masks, wait, failure_check)


def SegmentArc1Ext(handle, flags, axes, center, finalPoint, rotation, velocity, endVelocity, time, values, variables, index, masks, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, coordinates of the final point, direction of rotation, vector velocity,
	end motion velocity, and user variables parameters for the current segment."""
	return spb.SegmentArc1Ext(handle, flags, axes, center, finalPoint, rotation, velocity, endVelocity, time, values, variables, index, masks, wait, failure_check)


def ExtendedSegmentArc1(handle, flags, axes, center, finalPoint, rotation, velocity, endVelocity, time, values, variables, index, masks, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, coordinates of the final point, direction of rotation, vector velocity,
	end motion velocity, and user variables parameters for the current segment."""
	return spb.ExtendedSegmentArc1(handle, flags, axes, center, finalPoint, rotation, velocity, endVelocity, time, values, variables, index, masks, wait, failure_check)


def SegmentArc1V2(handle, flags, axes, center, finalPoint, rotation, velocity, endVelocity, time, values, variables, index, masks, extLoopType, minSegmentLength, maxAllowedDeviation, lciState, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, coordinates of the final point, direction of rotation, vector velocity,
	end motion velocity, and user variables parameters for the current segment."""
	return spb.SegmentArc1V2(handle, flags, axes, center, finalPoint, rotation, velocity, endVelocity, time, values, variables, index, masks, extLoopType, minSegmentLength, maxAllowedDeviation, lciState, wait, failure_check)


def Arc2(handle, axes, center, angle, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point and rotation angle."""
	return spb.Arc2(handle, axes, center, angle, wait, failure_check)


def ExtArc2(handle, axes, center, angle, velocity, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, rotation angle and the vector velocity for the current segment."""
	return spb.ExtArc2(handle, axes, center, angle, velocity, wait, failure_check)


def SegmentArc2(handle, flags, axes, center, angle, velocity, endVelocity, values, variables, index, masks, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, rotation angle, vector velocity,
	end motion velocity, and user variables parameters for the current segment."""
	return spb.SegmentArc2(handle, flags, axes, center, angle, velocity, endVelocity, values, variables, index, masks, wait, failure_check)


def SegmentArc2Ext(handle, flags, axes, center, angle, velocity, endVelocity, time, values, variables, index, masks, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, rotation angle, vector velocity,
	end motion velocity, and user variables parameters for the current segment."""
	return spb.SegmentArc2Ext(handle, flags, axes, center, angle, velocity, endVelocity, time, values, variables, index, masks, wait, failure_check)


def ExtendedSegmentArc2(handle, flags, axes, center, angle, finalPoint, velocity, endVelocity, time, values, variables, index, masks, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, rotation angle, final point for secondary axes, vector velocity,
	end motion velocity, and user variables parameters for the current segment."""
	return spb.ExtendedSegmentArc2(handle, flags, axes, center, angle, finalPoint, velocity, endVelocity, time, values, variables, index, masks, wait, failure_check)


def SegmentArc2V2(handle, flags, axes, center, angle, finalPoint, velocity, endVelocity, time, values, variables, index, masks, extLoopType, minSegmentLength, maxAllowedDeviation, lciState, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an arc segment to a segmented motion and specifies the coordinates
	of center point, rotation angle, final point for secondary axes, vector velocity,
	end motion velocity, and user variables parameters for the current segment."""
	return spb.SegmentArc2V2(handle, flags, axes, center, angle, finalPoint, velocity, endVelocity, time, values, variables, index, masks, extLoopType, minSegmentLength, maxAllowedDeviation, lciState, wait, failure_check)


def NurbsMotion(handle, flags, axes, velocity, exceptionAngle, exceptionLength, motionDelay, segments, wait=SYNCHRONOUS, failure_check=False):
	"""The function Create NURBS motion."""
	return spb.NurbsMotion(handle, flags, axes, velocity, exceptionAngle, exceptionLength, motionDelay, segments, wait, failure_check)


def NurbsPoints(handle, flags, axes, point, velocity, required_vel, knot, weight, wait=SYNCHRONOUS, failure_check=False):
	"""The function Add next control point to Nurbs MG."""
	return spb.NurbsPoints(handle, flags, axes, point, velocity, required_vel, knot, weight, wait, failure_check)


def SmoothPathMotion(handle, flags, axes, point, velocity, exceptionAngle, exceptionLength, motionDelay, segments, wait=SYNCHRONOUS, failure_check=False):
	"""The function Initiate a Path Smoothing Motion."""
	return spb.SmoothPathMotion(handle, flags, axes, point, velocity, exceptionAngle, exceptionLength, motionDelay, segments, wait, failure_check)


def SmoothPathSegment(handle, flags, axes, point, velocity, required_vel, wait=SYNCHRONOUS, failure_check=False):
	"""The function add a new control point to SPath MG."""
	return spb.SmoothPathSegment(handle, flags, axes, point, velocity, required_vel, wait, failure_check)


def Stopper(handle, axes, wait=SYNCHRONOUS, failure_check=False):
	"""The function provides a smooth transition between two segments of segmented motion."""
	return spb.Stopper(handle, axes, wait, failure_check)


def Projection(handle, axes, matrix, wait=SYNCHRONOUS, failure_check=False):
	"""The function sets a projection matrix for segmented motion."""
	return spb.Projection(handle, axes, matrix, wait, failure_check)


def AddPoint(handle, axis, point, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a point to a single-axis multi-point or spline motion."""
	return spb.AddPoint(handle, axis, point, wait, failure_check)


def AddPointM(handle, axes, point, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a point to a multi-axis multi-point or spline motion."""
	return spb.AddPointM(handle, axes, point, wait, failure_check)


def ExtAddPoint(handle, axis, point, rate, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a point to a single-axis multi-point or spline motion."""
	return spb.ExtAddPoint(handle, axis, point, rate, wait, failure_check)


def ExtAddPointM(handle, axes, point, rate, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a point to a multi-axis multi-point or spline motion."""
	return spb.ExtAddPointM(handle, axes, point, rate, wait, failure_check)


def AddPVTPoint(handle, axis, point, velocity, timeInterval, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a point to a single-axis PVT spline motion."""
	return spb.AddPVTPoint(handle, axis, point, velocity, timeInterval, wait, failure_check)


def AddPVTPointM(handle, axis, point, velocity, timeInterval, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a point to a multi-axis PVT spline motion."""
	return spb.AddPVTPointM(handle, axis, point, velocity, timeInterval, wait, failure_check)


def AddPVPoint(handle, axis, point, velocity, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a point to a single-axis PV spline motion."""
	return spb.AddPVPoint(handle, axis, point, velocity, wait, failure_check)


def AddPVPointM(handle, axis, point, velocity, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds a point to a multi-axis PV spline motion."""
	return spb.AddPVPointM(handle, axis, point, velocity, wait, failure_check)


def AddMPoint(handle, axis, name, count, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an array of points to a single-axis multi-point or spline motion."""
	return spb.AddMPoint(handle, axis, name, count, wait, failure_check)


def AddMPointM(handle, axes, name, count, wait=SYNCHRONOUS, failure_check=False):
	"""The function adds an array of points to a multi-axis multi-point or spline motion."""
	return spb.AddMPointM(handle, axes, name, count, wait, failure_check)


def EndSequence(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function informs the controller, that no more points will be specified for the current single-axis motion."""
	return spb.EndSequence(handle, axis, wait, failure_check)


def EndSequenceM(handle, axes, wait=SYNCHRONOUS, failure_check=False):
	"""The function informs the controller, that no more points or segments will be specified for the current multi-axis motion."""
	return spb.EndSequenceM(handle, axes, wait, failure_check)


def Collect(handle, flags, array, nSample, period, vars, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates data collection."""
	return spb.Collect(handle, flags, array, nSample, period, vars, wait, failure_check)


def CollectB(handle, flags, array, nSample, period, vars, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates data collection."""
	return spb.CollectB(handle, flags, array, nSample, period, vars, wait, failure_check)


def DataCollection(handle, flags, axis, array, nSample, period, vars, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates data collection."""
	return spb.DataCollection(handle, flags, axis, array, nSample, period, vars, wait, failure_check)


def DataCollectionExt(handle, flags, axis, array, nSample, period, vars, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates data collection."""
	return spb.DataCollectionExt(handle, flags, axis, array, nSample, period, vars, wait, failure_check)


def StopCollect(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function terminates data collection."""
	return spb.StopCollect(handle, wait, failure_check)


def SPDataCollectionStop(handle, servoProcessorIndex, wait=SYNCHRONOUS, failure_check=False):
	"""The function terminates Servo Processor Data Collection."""
	return spb.SPDataCollectionStop(handle, servoProcessorIndex, wait, failure_check)


def SPDataCollectionStart(handle, flags, array, nSample, period, servoProcessorIndex, servoProcessorAddress1, servoProcessorAddress2, servoProcessorAddress3, servoProcessorAddress4, wait=SYNCHRONOUS, failure_check=False):
	"""The function performs Servo Processor Data Collection for the specified Servo Processor
	variables with a constant maximum sampling rate of 20kHz."""
	return spb.SPDataCollectionStart(handle, flags, array, nSample, period, servoProcessorIndex, servoProcessorAddress1, servoProcessorAddress2, servoProcessorAddress3, servoProcessorAddress4, wait, failure_check)


def GetSPAddress(handle, flags, servoProcessorIndex, servoProcessorVariable, failure_check=False):
	"""The function reads address of the variable in the Servo Processor memory that is used for
	Servo_Processor_Data_Collection in EtherCAT network."""
	return spb.GetSPAddress(handle, flags, servoProcessorIndex, servoProcessorVariable, failure_check)


def GetMotorState(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current motor state."""
	return spb.GetMotorState(handle, axis, wait, failure_check)


def GetAxisState(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current axis state."""
	return spb.GetAxisState(handle, axis, wait, failure_check)


def GetIndexState(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current state of  the index and mark variables."""
	return spb.GetIndexState(handle, axis, wait, failure_check)


def ResetIndexState(handle, axis, mask, wait=SYNCHRONOUS, failure_check=False):
	"""The function resets the specified bits of the index/mark state."""
	return spb.ResetIndexState(handle, axis, mask, wait, failure_check)


def GetProgramState(handle, buffer, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current state of  the program buffer."""
	return spb.GetProgramState(handle, buffer, wait, failure_check)


def GetInput(handle, port, bit, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current state of  the specified digital input."""
	return spb.GetInput(handle, port, bit, wait, failure_check)


def GetInputPort(handle, port, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current state of  the specified digital input port."""
	return spb.GetInputPort(handle, port, wait, failure_check)


def GetOutput(handle, port, bit, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current state of  the specified digital output."""
	return spb.GetOutput(handle, port, bit, wait, failure_check)


def GetOutputPort(handle, port, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current state of  the specified digital output port."""
	return spb.GetOutputPort(handle, port, wait, failure_check)


def SetOutput(handle, port, bit, value, wait=SYNCHRONOUS, failure_check=False):
	"""The function sets the specified digital output to the specified value."""
	return spb.SetOutput(handle, port, bit, value, wait, failure_check)


def SetOutputPort(handle, port, value, wait=SYNCHRONOUS, failure_check=False):
	"""The function sets the specified digital output port to the specified value."""
	return spb.SetOutputPort(handle, port, value, wait, failure_check)


def GetAnalogInput(handle, port, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current numerical value of the specified analog inputs."""
	return spb.GetAnalogInput(handle, port, wait, failure_check)


def GetAnalogInputNT(handle, port, wait=SYNCHRONOUS, failure_check=False):
	""""""
	return spb.GetAnalogInputNT(handle, port, wait, failure_check)


def GetAnalogOutput(handle, port, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current numerical value of  the specified analog outputs."""
	return spb.GetAnalogOutput(handle, port, wait, failure_check)


def GetAnalogOutputNT(handle, port, wait=SYNCHRONOUS, failure_check=False):
	""""""
	return spb.GetAnalogOutputNT(handle, port, wait, failure_check)


def SetAnalogOutput(handle, port, value, wait=SYNCHRONOUS, failure_check=False):
	"""The function writes the current numerical value to the specified analog outputs."""
	return spb.SetAnalogOutput(handle, port, value, wait, failure_check)


def SetAnalogOutputNT(handle, port, value, wait=SYNCHRONOUS, failure_check=False):
	""""""
	return spb.SetAnalogOutputNT(handle, port, value, wait, failure_check)


def GetExtInput(handle, port, bit, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current state of  the specified extended input."""
	return spb.GetExtInput(handle, port, bit, wait, failure_check)


def GetExtInputPort(handle, port, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current state of  the specified extended input port."""
	return spb.GetExtInputPort(handle, port, wait, failure_check)


def GetExtOutput(handle, port, bit, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current state of  the specified extended output."""
	return spb.GetExtOutput(handle, port, bit, wait, failure_check)


def GetExtOutputPort(handle, port, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current state of  the specified extended output port."""
	return spb.GetExtOutputPort(handle, port, wait, failure_check)


def SetExtOutput(handle, port, bit, value, wait=SYNCHRONOUS, failure_check=False):
	"""The function sets the specified extended output to the specified value."""
	return spb.SetExtOutput(handle, port, bit, value, wait, failure_check)


def SetExtOutputPort(handle, port, value, wait=SYNCHRONOUS, failure_check=False):
	"""The function sets the specified extended output port to the specified value."""
	return spb.SetExtOutputPort(handle, port, value, wait, failure_check)


def GetFault(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the set of bits, that indicate the motor or system faults."""
	return spb.GetFault(handle, axis, wait, failure_check)


def GetFaultMask(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the mask, that defines which controller faults are examined and processed."""
	return spb.GetFaultMask(handle, axis, wait, failure_check)


def SetFaultMask(handle, axis, mask, wait=SYNCHRONOUS, failure_check=False):
	"""The function sets the mask, that enables/disables the examination and processing of the controller faults."""
	return spb.SetFaultMask(handle, axis, mask, wait, failure_check)


def EnableFault(handle, axis, fault, wait=SYNCHRONOUS, failure_check=False):
	"""The function enables the specified motor or system fault."""
	return spb.EnableFault(handle, axis, fault, wait, failure_check)


def DisableFault(handle, axis, fault, wait=SYNCHRONOUS, failure_check=False):
	"""The function disables the specified motor or system fault."""
	return spb.DisableFault(handle, axis, fault, wait, failure_check)


def GetResponseMask(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the mask, that defines for which motor or system faults the controller provides default response."""
	return spb.GetResponseMask(handle, axis, wait, failure_check)


def SetResponseMask(handle, axis, mask, wait=SYNCHRONOUS, failure_check=False):
	"""The function sets the mask, that defines for which motor or system faults the controller provides default response."""
	return spb.SetResponseMask(handle, axis, mask, wait, failure_check)


def EnableResponse(handle, axis, response, wait=SYNCHRONOUS, failure_check=False):
	"""The function enables the response to the specified motor or system fault."""
	return spb.EnableResponse(handle, axis, response, wait, failure_check)


def DisableResponse(handle, axis, response, wait=SYNCHRONOUS, failure_check=False):
	"""The function disables the default response to the specified motor or system fault."""
	return spb.DisableResponse(handle, axis, response, wait, failure_check)


def GetSafetyInput(handle, axis, input, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current state of  the specified safety input."""
	return spb.GetSafetyInput(handle, axis, input, wait, failure_check)


def GetSafetyInputPort(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the current state of  the specified safety input port."""
	return spb.GetSafetyInputPort(handle, axis, wait, failure_check)


def GetSafetyInputPortInv(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the set of bits that define inversion for the specified safety input port."""
	return spb.GetSafetyInputPortInv(handle, axis, wait, failure_check)


def SetSafetyInputPortInv(handle, axis, value, wait=SYNCHRONOUS, failure_check=False):
	"""The function sets the set of bits that define inversion for the specified safety input port."""
	return spb.SetSafetyInputPortInv(handle, axis, value, wait, failure_check)


def WaitMotionEnd(handle, axis, timeout, failure_check=False):
	"""The function waits for the end of a motion."""
	return spb.WaitMotionEnd(handle, axis, timeout, failure_check)


def WaitLogicalMotionEnd(handle, axis, timeout, failure_check=False):
	"""The function waits for the logical end of a motion."""
	return spb.WaitLogicalMotionEnd(handle, axis, timeout, failure_check)


def WaitCollectEndExt(handle, timeout, axis, failure_check=False):
	"""The function waits for the end of data collection.
	The function waits for the end of data collection."""
	return spb.WaitCollectEndExt(handle, timeout, axis, failure_check)


def WaitSPDataCollectionEnd(handle, timeout, servoProcessorIndex, failure_check=False):
	"""The function waits for the end of Servo Processor Data Collection."""
	return spb.WaitSPDataCollectionEnd(handle, timeout, servoProcessorIndex, failure_check)


def WaitProgramEnd(handle, buffer, timeout, failure_check=False):
	"""The function waits for the program termination in the specified buffer."""
	return spb.WaitProgramEnd(handle, buffer, timeout, failure_check)


def WaitMotorEnabled(handle, axis, state, timeout, failure_check=False):
	"""The function waits for the specified state of the specified motor."""
	return spb.WaitMotorEnabled(handle, axis, state, timeout, failure_check)


def WaitMotorCommutated(handle, axis, state, timeout, failure_check=False):
	"""The function waits for the specified state of the specified motor."""
	return spb.WaitMotorCommutated(handle, axis, state, timeout, failure_check)


def WaitInput(handle, port, bit, state, timeout, failure_check=False):
	"""The function waits for the specified state of digital input."""
	return spb.WaitInput(handle, port, bit, state, timeout, failure_check)


def WaitUserCondition(handle, userCondition, timeout, failure_check=False):
	"""The function waits for user-defined condition."""
	return spb.WaitUserCondition(handle, userCondition, timeout, failure_check)


def WaitPegReadyNT(handle, axis, timeout, failure_check=False):
	"""The function waits for the readiness of the PEG engine."""
	return spb.WaitPegReadyNT(handle, axis, timeout, failure_check)


def SetCallback(handle, callback, interrupt, failure_check=False):
	"""The function installs a user-defined callback function for the specified interrupt condition"""
	return spb.SetCallback(handle, callback, interrupt, failure_check)


def SetCallbackExt(handle, callback, cardContext, interrupt, failure_check=False):
	"""The function installs a user-defined callback function for the specified interrupt condition
	with specified card context"""
	return spb.SetCallbackExt(handle, callback, cardContext, interrupt, failure_check)


def InstallCallback(handle, callback, cardContext, interrupt, failure_check=False):
	"""The function installs a user-defined callback function for the specified interrupt condition
	with specified card context"""
	return spb.InstallCallback(handle, callback, cardContext, interrupt, failure_check)


def InstallCallbackExt(handle, callback, cardContext, interrupt, failure_check=False):
	"""The function installs a user-defined callback function for the specified interrupt condition
	with specified card context, supports more than 64 axes"""
	return spb.InstallCallbackExt(handle, callback, cardContext, interrupt, failure_check)


def SetCallbackPriority(handle, priority, failure_check=False):
	"""The function sets the priority for all callback threads."""
	return spb.SetCallbackPriority(handle, priority, failure_check)


def SetInterruptMask(handle, interrupt, mask, failure_check=False):
	"""The function sets the mask for specified interrupt"""
	return spb.SetInterruptMask(handle, interrupt, mask, failure_check)


def SetCallbackMaskExt(handle, interrupt, mask, failure_check=False):
	"""The function sets the mask for specified interrupt, supports more than 64 axes"""
	return spb.SetCallbackMaskExt(handle, interrupt, mask, failure_check)


def SetCallbackMask(handle, interrupt, mask, failure_check=False):
	"""The function sets the mask for specified callback"""
	return spb.SetCallbackMask(handle, interrupt, mask, failure_check)


def GetInterruptMask(handle, interrupt, failure_check=False):
	"""The function retrieves the mask for specified interrupt"""
	return spb.GetInterruptMask(handle, interrupt, failure_check)


def GetCallbackMask(handle, interrupt, failure_check=False):
	"""The function retrieves the mask for specified callback, supports more than 64 axes"""
	return spb.GetCallbackMask(handle, interrupt, failure_check)


def GetCallbackMaskExt(handle, interrupt, failure_check=False):
	"""The function retrieves the mask for specified callback (up to 128 axes)"""
	return spb.GetCallbackMaskExt(handle, interrupt, failure_check)


def DeclareVariable(handle, type, name, wait=SYNCHRONOUS, failure_check=False):
	"""The function creates the persistent global variable."""
	return spb.DeclareVariable(handle, type, name, wait, failure_check)


def ClearVariables(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function deletes all persistent global variables."""
	return spb.ClearVariables(handle, wait, failure_check)


def GetFirmwareVersion(handle, count=256, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the firmware version of the controller."""
	return spb.GetFirmwareVersion(handle, count, wait, failure_check)


def GetSerialNumber(handle, count=256, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the controller serial number."""
	return spb.GetSerialNumber(handle, count, wait, failure_check)


def KillExt(handle, axis, reason, wait=SYNCHRONOUS, failure_check=False):
	"""The function terminates a motion using reduced deceleration profile with Reason of kill."""
	return spb.KillExt(handle, axis, reason, wait, failure_check)


def DisableExt(handle, axis, reason, wait=SYNCHRONOUS, failure_check=False):
	"""The function disables motor and sets Reason of disable."""
	return spb.DisableExt(handle, axis, reason, wait, failure_check)


def GetMotorError(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the reason why the motor was disabled."""
	return spb.GetMotorError(handle, axis, wait, failure_check)


def GetMotionError(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the termination code of the last executed motion of the specified axis."""
	return spb.GetMotionError(handle, axis, wait, failure_check)


def GetProgramError(handle, buffer, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the error code of the last program error encountered in the specified buffer."""
	return spb.GetProgramError(handle, buffer, wait, failure_check)


def GetSharedMemoryAddress(handle, nBuf, var, wait=SYNCHRONOUS, failure_check=False):
	"""The function reads the address of shared memory variable."""
	return spb.GetSharedMemoryAddress(handle, nBuf, var, wait, failure_check)


def ReadSharedMemoryReal(handle, address, from1, to1, from2, to2, failure_check=False):
	"""The function reads value(s) from a real shared memory variable."""
	return spb.ReadSharedMemoryReal(handle, address, from1, to1, from2, to2, failure_check)


def ReadSharedMemoryInteger(handle, address, from1, to1, from2, to2, failure_check=False):
	"""The function reads value(s) from an integer shared memory variable."""
	return spb.ReadSharedMemoryInteger(handle, address, from1, to1, from2, to2, failure_check)


def WriteSharedMemoryReal(handle, address, from1, to1, from2, to2, values, failure_check=False):
	"""The function writes value(s) to the real shared memory variable."""
	return spb.WriteSharedMemoryReal(handle, address, from1, to1, from2, to2, values, failure_check)


def WriteSharedMemoryInteger(handle, address, from1, to1, from2, to2, values, failure_check=False):
	"""The function writes value(s) to the integer shared memory variable."""
	return spb.WriteSharedMemoryInteger(handle, address, from1, to1, from2, to2, values, failure_check)


def SetServer(iP, failure_check=False):
	"""This function defines communication server IP address"""
	return spb.SetServer(iP, failure_check)


def SetServerExt(iP, port, failure_check=False):
	"""This function defines communication server IP address and Port"""
	return spb.SetServerExt(iP, port, failure_check)


def SetServerExtLogin(iP, port, username, password, domain, failure_check=False):
	"""The function defines the User Mode Driver (UMD) host IP address, and port along with passing login
	data."""
	return spb.SetServerExtLogin(iP, port, username, password, domain, failure_check)


def PegInc(handle, flags, axis, width, firstPoint, interval, lastPoint, tbNumber, tbPeriod, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates incremental PEG. Incremental PEG function is defined by first point, last point
	and the interval."""
	return spb.PegInc(handle, flags, axis, width, firstPoint, interval, lastPoint, tbNumber, tbPeriod, wait, failure_check)


def PegRandom(handle, flags, axis, width, pointArray, stateArray, tbNumber, tbPeriod, wait=SYNCHRONOUS, failure_check=False):
	"""The function initiates random PEG. Random PEG function specifies an array of points where
	position - based events should be generated."""
	return spb.PegRandom(handle, flags, axis, width, pointArray, stateArray, tbNumber, tbPeriod, wait, failure_check)


def AssignPins(handle, axis, mask, wait=SYNCHRONOUS, failure_check=False):
	"""The function defines whether a digital output is allocated to the corresponding bit of the OUT array
	(for general purpose use) or allocated for PEG function use."""
	return spb.AssignPins(handle, axis, mask, wait, failure_check)


def StopPeg(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function stops PEG."""
	return spb.StopPeg(handle, axis, wait, failure_check)


def AssignPegNT(handle, axis, engToEncBitCode, gpOutsBitCode, wait=SYNCHRONOUS, failure_check=False):
	"""This function is used for engine-to-encoder assignment as well as for the additional digital outputs
	assignment for use as PEG stateand PEG pulse outputs.As of V3.12, a new flag is available calling for
	fast loading of Random PEG arrays"""
	return spb.AssignPegNT(handle, axis, engToEncBitCode, gpOutsBitCode, wait, failure_check)


def AssignPegNTV2(handle, flags, axis, engToEncBitCode, gpOutsBitCode, wait=SYNCHRONOUS, failure_check=False):
	"""This function is used for engine-to-encoder assignment as well as for the additional digital outputs
	assignment for use as PEG stateand PEG pulse outputs.As of V3.12, a new flag is available calling for
	fast loading of Random PEG arrays"""
	return spb.AssignPegNTV2(handle, flags, axis, engToEncBitCode, gpOutsBitCode, wait, failure_check)


def AssignPegOutputsNT(handle, axis, outputIndex, bitCode, wait=SYNCHRONOUS, failure_check=False):
	"""The function is used for setting output pins assignment and mapping between FGP_OUT signals to
	the bits of the ACSPL + OUT(x) variable, where x is the index that has been assigned to the controller
	in the network during System Configuration."""
	return spb.AssignPegOutputsNT(handle, axis, outputIndex, bitCode, wait, failure_check)


def AssignFastInputsNT(handle, axis, inputIndex, bitCode, wait=SYNCHRONOUS, failure_check=False):
	"""The function is used to switch MARK_1 physical inputs to ACSPL+ variables as fast general purpose
	inputs."""
	return spb.AssignFastInputsNT(handle, axis, inputIndex, bitCode, wait, failure_check)


def PegIncNT(handle, flags, axis, width, firstPoint, interval, lastPoint, tbNumber, tbPeriod, wait=SYNCHRONOUS, failure_check=False):
	"""The function is used for setting the parameters for the Incremental PEG mode. The Incremental PEG
	function is defined by first point, last point and the interval."""
	return spb.PegIncNT(handle, flags, axis, width, firstPoint, interval, lastPoint, tbNumber, tbPeriod, wait, failure_check)


def PegIncNTV2(handle, flags, axis, width, firstPoint, interval, lastPoint, errMapAxis1, axisCoord1, errMapAxis2, axisCoord2, errMapMaxSize, minDirDistance, tbNumber, tbPeriod, wait=SYNCHRONOUS, failure_check=False):
	"""The function is used for setting the parameters for the Incremental PEG mode and support dynamic error compensation.The Incremental PEG
	function is defined by first point, last point and the interval."""
	return spb.PegIncNTV2(handle, flags, axis, width, firstPoint, interval, lastPoint, errMapAxis1, axisCoord1, errMapAxis2, axisCoord2, errMapMaxSize, minDirDistance, tbNumber, tbPeriod, wait, failure_check)


def PegRandomNT(handle, flags, axis, width, mode, firstIndex, lastIndex, pointArray, stateArray, tbNumber, tbPeriod, wait=SYNCHRONOUS, failure_check=False):
	"""The function is used for setting the parameters for the Random PEG mode. The Random PEG
	function specifies an array of points where position - based events are to be generated."""
	return spb.PegRandomNT(handle, flags, axis, width, mode, firstIndex, lastIndex, pointArray, stateArray, tbNumber, tbPeriod, wait, failure_check)


def PegRandomNTV2(handle, flags, axis, width, mode, firstIndex, lastIndex, pointArray, stateArray, errMapAxis1, axisCoord1, errMapAxis2, axisCoord2, minDirDistance, tbNumber, tbPeriod, wait=SYNCHRONOUS, failure_check=False):
	"""The function is used for setting the parameters for the Random PEG mode and support dynamic error compensation. The Random PEG
	function specifies an array of points where position - based events are to be generated."""
	return spb.PegRandomNTV2(handle, flags, axis, width, mode, firstIndex, lastIndex, pointArray, stateArray, errMapAxis1, axisCoord1, errMapAxis2, axisCoord2, minDirDistance, tbNumber, tbPeriod, wait, failure_check)


def StartPegNT(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function is used to initiate the PEG process."""
	return spb.StartPegNT(handle, axis, wait, failure_check)


def StopPegNT(handle, axis, wait=SYNCHRONOUS, failure_check=False):
	"""The function is used to terminate the PEG process immediately on the specified axis. The function
	can be used in both the Incrementaland Random PEG modes."""
	return spb.StopPegNT(handle, axis, wait, failure_check)


def DynamicErrorCompensationOn(handle, axis, zone, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This function receives axis index and zone index. This function activates
	error correction for the mechanical error compensation for the specified zone."""
	return spb.DynamicErrorCompensationOn(handle, axis, zone, wait, failure_check)


def DynamicErrorCompensationOff(handle, axis, zone, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This function receives axis index and zone index. The This function
	deactivates error mapping correction for the mechanical error compensation for the specified zone."""
	return spb.DynamicErrorCompensationOff(handle, axis, zone, wait, failure_check)


def DynamicErrorCompensationRemove(handle, axis, zone, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This function receives axis index and zone index. This function deactivates
	error correction for the mechanical error compensation for the specified zone."""
	return spb.DynamicErrorCompensationRemove(handle, axis, zone, wait, failure_check)


def DynamicErrorCompensation1D(handle, flags, axis, zone, base0, step0, correctionMapVariable, referencedAxisOrAnalogInput, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This function configures and activates 1D error correction for the mechanical error
	compensation for the specified zone, so that the compensated reference position will be calculated
	by subtracting the linearly(by default) interpolated error from the desired position so that the actual
	value will be closer to the desired value.
	The calculation assumes fixed Intervals between points inside the zone."""
	return spb.DynamicErrorCompensation1D(handle, flags, axis, zone, base0, step0, correctionMapVariable, referencedAxisOrAnalogInput, wait, failure_check)


def DynamicErrorCompensationN1D(handle, flags, axis, zone, axisCommands, correctionMapVariable, referencedAxisOrAnalogInput, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This function configures and activates 1D error correction for the mechanical error
	compensation for the specified zone, so that the compensated reference position will be calculated
	by subtracting the linearly(by default) interpolated error from the desired position so that the actual
	value will be closer to the desired value.
	The calculation is based on an arbitrary network of points inside the zone."""
	return spb.DynamicErrorCompensationN1D(handle, flags, axis, zone, axisCommands, correctionMapVariable, referencedAxisOrAnalogInput, wait, failure_check)


def DynamicErrorCompensationA1D(handle, flags, axis, zone, scalingFactor, offset, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This function configures and activates 1D error correction for the mechanical error
	compensation for the specified zone, so that the compensated reference position will be calculated
	by multiplying the scaling factor by the desired position so that the actual value will be closer to the
	desired value."""
	return spb.DynamicErrorCompensationA1D(handle, flags, axis, zone, scalingFactor, offset, wait, failure_check)


def DynamicErrorCompensation2D(handle, flags, axis0, axis1, zone, base0, step0, base1, step1, correctionMapVariable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This configures and activates 2D error correction for the mechanical error
	compensation of the �axis0� command for the specified zone, so that the compensated reference position will
	be calculated by subtracting the linearly (by default) interpolated error from the desired position so that the actual
	value will be closer to the desired value."""
	return spb.DynamicErrorCompensation2D(handle, flags, axis0, axis1, zone, base0, step0, base1, step1, correctionMapVariable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, wait, failure_check)


def DynamicErrorCompensationN2D(handle, flags, axis0, axis1, zone, axis0Commands, axis1Commands, correctionMapVariable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This configures and activates 2D error correction for the mechanical error
	compensation of the �axis0� command for the specified zone, so that the compensated reference position will
	be calculated by subtracting the linearly (by default) interpolated error from the desired position so that the actual
	value will be closer to the desired value.
	The calculation is based on an arbitrary network of points inside the zone."""
	return spb.DynamicErrorCompensationN2D(handle, flags, axis0, axis1, zone, axis0Commands, axis1Commands, correctionMapVariable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, wait, failure_check)


def DynamicErrorCompensationA2D(handle, flags, axis0, axis1, zone, angle, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: function configures and activates 2D error correction for the mechanical
	error compensation of the specified axis for the specified zone, so that the compensated reference position will be
	calculated by taking into account the angle for the orthogonality correction so that the actual value will be closer to
	the desired value."""
	return spb.DynamicErrorCompensationA2D(handle, flags, axis0, axis1, zone, angle, wait, failure_check)


def DynamicErrorCompensation3D2(handle, flags, axis0, axis1, axis2, zone, base0, step0, base1, step1, base2, step2, correctionMap0Variable, correctionMap1Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This configures and activates 3D error correction for the mechanical error
	compensation of the �axis0� command, �axis1� command, and 'axis2' command for the specified zone,
	so that the compensated reference position will be calculated by adding the linearly (by default) interpolated error
	from the desired position so that the actual value will be closer to the desired value."""
	return spb.DynamicErrorCompensation3D2(handle, flags, axis0, axis1, axis2, zone, base0, step0, base1, step1, base2, step2, correctionMap0Variable, correctionMap1Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait, failure_check)


def DynamicErrorCompensation3D3(handle, flags, axis0, axis1, axis2, zone, base0, step0, base1, step1, base2, step2, correctionMap0Variable, correctionMap1Variable, correctionMap2Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This configures and activates 3D error correction for the mechanical error
	compensation of the �axis0� command, �axis1� command, and 'axis2' command for the specified zone,
	so that the compensated reference position will be calculated by adding the linearly (by default) interpolated error
	from the desired position so that the actual value will be closer to the desired value."""
	return spb.DynamicErrorCompensation3D3(handle, flags, axis0, axis1, axis2, zone, base0, step0, base1, step1, base2, step2, correctionMap0Variable, correctionMap1Variable, correctionMap2Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait, failure_check)


def DynamicErrorCompensation3D5(handle, flags, axis0, axis1, axis2, zone, base0, step0, base1, step1, base2, step2, correctionMap0Variable, correctionMap1Variable, correctionMap2Variable, correctionMap3Variable, correctionMap4Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This configures and activates 3D error correction for the mechanical error
	compensation of the �axis0� command, �axis1� command, and 'axis2' command for the specified zone,
	so that the compensated reference position will be calculated by adding the linearly (by default) interpolated error
	from the desired position so that the actual value will be closer to the desired value."""
	return spb.DynamicErrorCompensation3D5(handle, flags, axis0, axis1, axis2, zone, base0, step0, base1, step1, base2, step2, correctionMap0Variable, correctionMap1Variable, correctionMap2Variable, correctionMap3Variable, correctionMap4Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait, failure_check)


def DynamicErrorCompensation3DA(handle, flags, axis0, axis1, axis2, zone, base0, step0, base1, step1, base2, step2, correctionMap0Variable, correctionMap1Variable, correctionMap2Variable, correctionMap3Variable, correctionMap4Variable, correctionMap5Variable, correctionMap6Variable, correctionMap7Variable, correctionMap8Variable, correctionMap9Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This configures and activates 3D error correction for the mechanical error
	compensation of the �axis0� command, �axis1� command, and 'axis2' command for the specified zone,
	so that the compensated reference position will be calculated by adding the linearly (by default) interpolated error
	from the desired position so that the actual value will be closer to the desired value."""
	return spb.DynamicErrorCompensation3DA(handle, flags, axis0, axis1, axis2, zone, base0, step0, base1, step1, base2, step2, correctionMap0Variable, correctionMap1Variable, correctionMap2Variable, correctionMap3Variable, correctionMap4Variable, correctionMap5Variable, correctionMap6Variable, correctionMap7Variable, correctionMap8Variable, correctionMap9Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait, failure_check)


def DynamicErrorCompensationN3D2(handle, flags, axis0, axis1, axis2, zone, axis0Commands, axis1Commands, axis2Commands, correctionMap0Variable, correctionMap1Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This configures and activates 3D error correction for the mechanical error
	compensation of the �axis0� command, �axis1� command, and 'axis2' command for the specified zone,
	so that the compensated reference position will be calculated by adding the linearly (by default) interpolated error
	from the desired position so that the actual value will be closer to the desired value."""
	return spb.DynamicErrorCompensationN3D2(handle, flags, axis0, axis1, axis2, zone, axis0Commands, axis1Commands, axis2Commands, correctionMap0Variable, correctionMap1Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait, failure_check)


def DynamicErrorCompensationN3D3(handle, flags, axis0, axis1, axis2, zone, axis0Commands, axis1Commands, axis2Commands, correctionMap0Variable, correctionMap1Variable, correctionMap2Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This configures and activates 3D error correction for the mechanical error
	compensation of the �axis0� command, �axis1� command, and 'axis2' command for the specified zone,
	so that the compensated reference position will be calculated by adding the linearly (by default) interpolated error
	from the desired position so that the actual value will be closer to the desired value."""
	return spb.DynamicErrorCompensationN3D3(handle, flags, axis0, axis1, axis2, zone, axis0Commands, axis1Commands, axis2Commands, correctionMap0Variable, correctionMap1Variable, correctionMap2Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait, failure_check)


def DynamicErrorCompensationN3D5(handle, flags, axis0, axis1, axis2, zone, axis0Commands, axis1Commands, axis2Commands, correctionMap0Variable, correctionMap1Variable, correctionMap2Variable, correctionMap3Variable, correctionMap4Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This configures and activates 3D error correction for the mechanical error
	compensation of the �axis0� command, �axis1� command, and 'axis2' command for the specified zone,
	so that the compensated reference position will be calculated by adding the linearly (by default) interpolated error
	from the desired position so that the actual value will be closer to the desired value."""
	return spb.DynamicErrorCompensationN3D5(handle, flags, axis0, axis1, axis2, zone, axis0Commands, axis1Commands, axis2Commands, correctionMap0Variable, correctionMap1Variable, correctionMap2Variable, correctionMap3Variable, correctionMap4Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait, failure_check)


def DynamicErrorCompensationN3DA(handle, flags, axis0, axis1, axis2, zone, axis0Commands, axis1Commands, axis2Commands, correctionMap0Variable, correctionMap1Variable, correctionMap2Variable, correctionMap3Variable, correctionMap4Variable, correctionMap5Variable, correctionMap6Variable, correctionMap7Variable, correctionMap8Variable, correctionMap9Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait=SYNCHRONOUS, failure_check=False):
	"""Dynamic Error Compensation: This configures and activates 3D error correction for the mechanical error
	compensation of the �axis0� command, �axis1� command, and 'axis2' command for the specified zone,
	so that the compensated reference position will be calculated by adding the linearly (by default) interpolated error
	from the desired position so that the actual value will be closer to the desired value."""
	return spb.DynamicErrorCompensationN3DA(handle, flags, axis0, axis1, axis2, zone, axis0Commands, axis1Commands, axis2Commands, correctionMap0Variable, correctionMap1Variable, correctionMap2Variable, correctionMap3Variable, correctionMap4Variable, correctionMap5Variable, correctionMap6Variable, correctionMap7Variable, correctionMap8Variable, correctionMap9Variable, referencedAxisOrAnalogInput0, referencedAxisOrAnalogInput1, referencedAxisOrAnalogInput2, wait, failure_check)


def SetLogFileOptions(handle, detalization, presentation, failure_check=False):
	"""The function sets the log file options."""
	return spb.SetLogFileOptions(handle, detalization, presentation, failure_check)


def LoadDataToController(handle, dest, destName, from1, to1, from2, to2, srcFileName, srcNumFormat, bTranspose, wait=SYNCHRONOUS, failure_check=False):
	"""The function writes value(s) from text file to SPiiPlus controller (variable or file)."""
	return spb.LoadDataToController(handle, dest, destName, from1, to1, from2, to2, srcFileName, srcNumFormat, bTranspose, wait, failure_check)


def UploadDataFromController(handle, src, srcName, srcNumFormat, from1, to1, from2, to2, destFileName, destNumFormat, bTranspose, wait=SYNCHRONOUS, failure_check=False):
	"""This function writes value(s) from the SPiiPlus controller (variable or file) to a text file."""
	return spb.UploadDataFromController(handle, src, srcName, srcNumFormat, from1, to1, from2, to2, destFileName, destNumFormat, bTranspose, wait, failure_check)


def CopyFileToController(handle, sourceFileName, destinationFileName, wait=SYNCHRONOUS, failure_check=False):
	"""The function copies file to controller"""
	return spb.CopyFileToController(handle, sourceFileName, destinationFileName, wait, failure_check)


def DeleteFileFromController(handle, fileName, wait=SYNCHRONOUS, failure_check=False):
	"""The function deletes file from controller"""
	return spb.DeleteFileFromController(handle, fileName, wait, failure_check)


def GetConnectionsList(maxNumConnections=32, failure_check=False):
	"""The function retrieves the list of all currently opened communication channels(connections), on active Server."""
	return spb.GetConnectionsList(maxNumConnections, failure_check)


def GetConnectionInfo(handle, failure_check=False):
	"""The function retrieves additional information of specified connection, on active Server. """
	return spb.GetConnectionInfo(handle, failure_check)


def TerminateConnection(connection, failure_check=False):
	"""The function terminates single communication channel(connection), on active Server."""
	return spb.TerminateConnection(connection, failure_check)


def RegisterEmergencyStop(failure_check=False):
	"""The function initiates the Emergency Stop functionality for calling application."""
	return spb.RegisterEmergencyStop(failure_check)


def UnregisterEmergencyStop(failure_check=False):
	"""The function terminates the Emergency Stop functionality for the calling application."""
	return spb.UnregisterEmergencyStop(failure_check)


def GetUMDVersion():
	"""The function returns version of UMD                                                """
	return spb.GetUMDVersion()


def AnalyzeApplication(handle, fileName, wait=SYNCHRONOUS, failure_check=False):
	"""The function analyzes an application file and returns information about the file�s components, such
	as, saved ACSPL + programs, configuration parameters, user files, etc."""
	return spb.AnalyzeApplication(handle, fileName, wait, failure_check)


def FreeApplication(info, failure_check=False):
	"""The function frees memory previously allocated by the AnalyzeApplication function."""
	return spb.FreeApplication(info, failure_check)


def SaveApplication(handle, fileName, info, wait=SYNCHRONOUS, failure_check=False):
	"""The function saves a user application from the controller to a file on the host PC."""
	return spb.SaveApplication(handle, fileName, info, wait, failure_check)


def LoadApplication(handle, fileName, info, wait=SYNCHRONOUS, failure_check=False):
	"""The function loads a section of data from the host PC disk and saves it in the controller�s files."""
	return spb.LoadApplication(handle, fileName, info, wait, failure_check)


def DefineControllerProtection(handle, flags, noEditBuffers, noViewBuffers, standardVariables, password, timeout, failure_check=False):
	"""Controller Protection: The function applies protection for controller."""
	return spb.DefineControllerProtection(handle, flags, noEditBuffers, noViewBuffers, standardVariables, password, timeout, failure_check)


def RemoveControllerProtection(handle, flags, password, timeout, failure_check=False):
	"""Controller Protection: The function removes protection from controller."""
	return spb.RemoveControllerProtection(handle, flags, password, timeout, failure_check)


def TemporarilyDisableVariableProtection(handle, password, wait=SYNCHRONOUS, failure_check=False):
	"""Controller Protection: The function Temporarily Disables Variable Protection"""
	return spb.TemporarilyDisableVariableProtection(handle, password, wait, failure_check)


def RestoreVariableProtection(handle, wait=SYNCHRONOUS, failure_check=False):
	"""Controller Protection: The function Restore Variable Protection That Was Temporarily Disabled"""
	return spb.RestoreVariableProtection(handle, wait, failure_check)


def ControllerReboot(handle, timeout, failure_check=False):
	"""The function reboots controller and waits for process completion."""
	return spb.ControllerReboot(handle, timeout, failure_check)


def ControllerFactoryDefault(handle, timeout, failure_check=False):
	"""The function reboots controller, restores factory default settings and waits for process completion"""
	return spb.ControllerFactoryDefault(handle, timeout, failure_check)


def ControllerSaveToFlash(handle, parameters, buffers, sPPrograms, userArrays, failure_check=False):
	"""This function saves to flash"""
	return spb.ControllerSaveToFlash(handle, parameters, buffers, sPPrograms, userArrays, failure_check)


def GetEtherCATState(handle, wait=SYNCHRONOUS, failure_check=False):
	"""This function is used to retrieve the EtherCAT state."""
	return spb.GetEtherCATState(handle, wait, failure_check)


def GetEtherCATError(handle, wait=SYNCHRONOUS, failure_check=False):
	"""this function is used to retrieve the last EtherCAT error"""
	return spb.GetEtherCATError(handle, wait, failure_check)


def MapEtherCATInput(handle, flags, offset, variableName, wait=SYNCHRONOUS, failure_check=False):
	"""The function is used for raw mapping of network input variables of any size. Once the function is
	called successfully, the firmware copies the value of the network input variable at the corresponding
	EtherCAT offset into the ACSPL + variable, every controller cycle."""
	return spb.MapEtherCATInput(handle, flags, offset, variableName, wait, failure_check)


def MapEtherCATOutput(handle, flags, offset, variableName, wait=SYNCHRONOUS, failure_check=False):
	"""The function is used for raw mapping of network output variables of any size. Once the function is
	called successfully, the firmware copies the value of specified ACSPL + variable into the network
	output variable at the corresponding EtherCAT offset, every controller cycle."""
	return spb.MapEtherCATOutput(handle, flags, offset, variableName, wait, failure_check)


def UnmapEtherCATInputsOutputs(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function resets all previous mapping defined by MapEtherCATInput and MapEtherCATOutput."""
	return spb.UnmapEtherCATInputsOutputs(handle, wait, failure_check)


def GetEtherCATSlaveIndex(handle, vendorID, productID, count, wait=SYNCHRONOUS, failure_check=False):
	"""The function returns the index of EtherCAT slave according to the parameters that are specified."""
	return spb.GetEtherCATSlaveIndex(handle, vendorID, productID, count, wait, failure_check)


def GetEtherCATSlaveOffset(handle, variableName, slaveIndex, wait=SYNCHRONOUS, failure_check=False):
	"""The function returns offset of a network variable of the specified EtherCAT slave in EtherCAT telegram."""
	return spb.GetEtherCATSlaveOffset(handle, variableName, slaveIndex, wait, failure_check)


def GetEtherCATSlaveOffsetV2(handle, flags, variableName, slaveIndex, wait=SYNCHRONOUS, failure_check=False):
	"""The function returns offset of a network variable of the specified EtherCAT slave in EtherCAT telegram.
	The EtherCAT network is identified by Flags parameter."""
	return spb.GetEtherCATSlaveOffsetV2(handle, flags, variableName, slaveIndex, wait, failure_check)


def GetEtherCATSlaveVendorID(handle, slaveIndex, wait=SYNCHRONOUS, failure_check=False):
	"""The function returns the Vendor ID of specified EtherCAT slave."""
	return spb.GetEtherCATSlaveVendorID(handle, slaveIndex, wait, failure_check)


def GetEtherCATSlaveVendorIDV2(handle, flags, slaveIndex, wait=SYNCHRONOUS, failure_check=False):
	"""The function returns the Vendor ID of specified EtherCAT slave.
	The EtherCAT network is identified by Flags parameter."""
	return spb.GetEtherCATSlaveVendorIDV2(handle, flags, slaveIndex, wait, failure_check)


def GetEtherCATSlaveSerialNumber(handle, flags, slaveIndex, wait=SYNCHRONOUS, failure_check=False):
	"""This function is used to retrieve the EtherCAT slave Serial number.
	The EtherCAT network is identified by Flags parameter."""
	return spb.GetEtherCATSlaveSerialNumber(handle, flags, slaveIndex, wait, failure_check)


def GetEtherCATSlaveProductID(handle, slaveIndex, wait=SYNCHRONOUS, failure_check=False):
	"""The function returns the Product ID of the specified EtherCAT slave."""
	return spb.GetEtherCATSlaveProductID(handle, slaveIndex, wait, failure_check)


def GetEtherCATSlaveProductIDV2(handle, flags, slaveIndex, wait=SYNCHRONOUS, failure_check=False):
	"""The function returns the Product ID of the specified EtherCAT slave.
	The EtherCAT network is identified by Flags parameter."""
	return spb.GetEtherCATSlaveProductIDV2(handle, flags, slaveIndex, wait, failure_check)


def GetEtherCATSlaveRevision(handle, slaveIndex, wait=SYNCHRONOUS, failure_check=False):
	"""The function returns the Revision of the specified EtherCAT slave."""
	return spb.GetEtherCATSlaveRevision(handle, slaveIndex, wait, failure_check)


def GetEtherCATSlaveRevisionV2(handle, flags, slaveIndex, wait=SYNCHRONOUS, failure_check=False):
	"""The function returns the Revision of the specified EtherCAT slave..
	The EtherCAT network is identified by Flags parameter."""
	return spb.GetEtherCATSlaveRevisionV2(handle, flags, slaveIndex, wait, failure_check)


def GetEtherCATSlaveType(handle, vendorID, productID, wait=SYNCHRONOUS, failure_check=False):
	"""The function returns the type of the specified EtherCAT slave."""
	return spb.GetEtherCATSlaveType(handle, vendorID, productID, wait, failure_check)


def GetEtherCATSlaveState(handle, slaveIndex, wait=SYNCHRONOUS, failure_check=False):
	"""The function returns the EtherCAT machine state of the specified EtherCAT slave."""
	return spb.GetEtherCATSlaveState(handle, slaveIndex, wait, failure_check)


def GetEtherCATSlaveStateV2(handle, flags, slaveIndex, wait=SYNCHRONOUS, failure_check=False):
	"""The function returns the EtherCAT machine state of the specified EtherCAT slave.
	The EtherCAT network is identified by Flags parameter."""
	return spb.GetEtherCATSlaveStateV2(handle, flags, slaveIndex, wait, failure_check)


def DownloadFileOverEtherCAT(handle, path, filename, slaveIndex, wait=SYNCHRONOUS, failure_check=False):
	"""The function downloads a file over EtherCAT from the controller�s flash to slave.
	The EtherCAT network is identified by Flags parameter."""
	return spb.DownloadFileOverEtherCAT(handle, path, filename, slaveIndex, wait, failure_check)


def ReadSDOValueOverEtherCAT(handle, flags, slaveIndex, index, subIndex, wait=SYNCHRONOUS, failure_check=False):
	"""This function is used to read Object Dictionary entry from CoE slave.
	The EtherCAT network is identified by Flags parameter."""
	return spb.ReadSDOValueOverEtherCAT(handle, flags, slaveIndex, index, subIndex, wait, failure_check)


def WriteSDOValueOverEtherCAT(handle, flags, slaveIndex, index, subIndex, value, wait=SYNCHRONOUS, failure_check=False):
	"""This function is used to write a value into the CoE slave Object Dictionary.
	The EtherCAT network is identified by Flags parameter."""
	return spb.WriteSDOValueOverEtherCAT(handle, flags, slaveIndex, index, subIndex, value, wait, failure_check)


def GetEtherCATSlaveRegister(handle, flags, slaveIndex, offset, wait=SYNCHRONOUS, failure_check=False):
	"""ESC Error Counters Registers (Beckhoff Memory). The ESCs have numerous error counters that help
	you detectand locate errors.This function enables you to view the contents of these registers
	The EtherCAT network is identified by Flags parameter."""
	return spb.GetEtherCATSlaveRegister(handle, flags, slaveIndex, offset, wait, failure_check)


def ClearEtherCATSlaveRegister(handle, flags, slaveIndex, offset, wait=SYNCHRONOUS, failure_check=False):
	"""This function is used to retrieve the EtherCAT state.
	The EtherCAT network is identified by Flags parameter."""
	return spb.ClearEtherCATSlaveRegister(handle, flags, slaveIndex, offset, wait, failure_check)


def GetEtherCATSlavesCount(handle, flags, wait=SYNCHRONOUS, failure_check=False):
	"""This function is used to retrieve the number of EtherCAT slaves connected to the master.
	The EtherCAT network is identified by Flags parameter."""
	return spb.GetEtherCATSlavesCount(handle, flags, wait, failure_check)


def GetVolatileMemoryUsage(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the percentage of the volatile memory load."""
	return spb.GetVolatileMemoryUsage(handle, wait, failure_check)


def GetVolatileMemoryTotal(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the amount of total volatile memory in bytes."""
	return spb.GetVolatileMemoryTotal(handle, wait, failure_check)


def GetVolatileMemoryFree(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the amount of free volatile memory in bytes."""
	return spb.GetVolatileMemoryFree(handle, wait, failure_check)


def GetNonVolatileMemoryUsage(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the percentage of the non-volatile memory load."""
	return spb.GetNonVolatileMemoryUsage(handle, wait, failure_check)


def GetNonVolatileMemoryTotal(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the amount of total non-volatile memory in bytes."""
	return spb.GetNonVolatileMemoryTotal(handle, wait, failure_check)


def GetNonVolatileMemoryFree(handle, wait=SYNCHRONOUS, failure_check=False):
	"""The function retrieves the amount of free non-volatile memory in bytes."""
	return spb.GetNonVolatileMemoryFree(handle, wait, failure_check)


def StartSPiiPlusSC(failure_check=False):
	"""The function starts the SPiiPlusSC controller."""
	return spb.StartSPiiPlusSC(failure_check)


def StopSPiiPlusSC(failure_check=False):
	"""The function stops the SPiiPlusSC controller."""
	return spb.StopSPiiPlusSC(failure_check)


def CloseSimulator(failure_check=False):
	"""The function Stops the SPiiPlus simulator via UMD in the case that it is running."""
	return spb.CloseSimulator(failure_check)


def OpenCommSimulator():
	"""The function executes the SPiiPlus stand-alone simulator via SPiiPlus User ModeDriver in the case
	that it is not running.
	The function connects to the simulator via TCP / IP protocol."""
	return spb.OpenCommSimulator()


def FRF_InitInput() -> Union[Tuple[AcsError, int], FRF_INPUT]:
	"""Initializes the inputParams structure of the “FRF_Measure” function to valid initial values."""
	return spb.FRF_InitInput()


def FRF_Measure(handle: int, frf_input: FRF_INPUT) -> Union[Tuple[AcsError, int], FRF_OUTPUT]:
	"""This function initializes FRF measurement."""
	return spb.FRF_Measure(handle, frf_input)


def FRF_Stop(handle: int, axis: int) -> Union[Tuple[AcsError, int], None]:
	"""Function aborts FRF measurement. If FRF was aborted “outputParams” will not contain valid data
	(all pointers will be set to nullptr) and errorCode will reflect that FRF was aborted by the user."""
	return spb.FRF_Stop(handle, axis)


def FRF_CalculateMeasurementDuration(params: FRF_DURATION_CALCULATION_PARAMETERS)\
		-> Union[Tuple[AcsError, int], float]:
	"""This function calculates the required duration of measurement (DurationSec parameter of FRFInput
	class) in order to satisfy the specified frequency resolution."""
	return spb.FRF_CalculateMeasurementDuration(params)


def FRF_ReadServoParameters(handle: int, axis: int) -> Union[Tuple[AcsError, int], SERVO_PARAMETERS]:
	"""The function reads all required servo parameters for calculation of Controller, OpenLoop, ClosedLoop etc."""
	return spb.FRF_ReadServoParameters(handle, axis)


#def FRF_CalculateLoopDataFRD(loopData: FRF_CALCULATE_LOOP_DATA) -> Union[Tuple[AcsError, int], FRD]:
#    """This function Calculate the loop data."""
#    return spb.FRF_CalculateLoopDataFRD(loopData)


def FRF_CalculateControllerFRD(servoParameters: SERVO_PARAMETERS, loopType: FRF_LOOP_TYPE, frequencyHz: List[float])\
		-> Union[Tuple[AcsError, int], FRD]:
	"""The function calculates controller FRD (Frequency Response Data) based on servo parameters,
	servo loop and frequency vector."""
	return spb.FRF_CalculateControllerFRD(servoParameters, loopType, frequencyHz)


def FRF_CalculateOpenLoopFRD(servoParameters: SERVO_PARAMETERS, plant: FRD, loopType: FRF_LOOP_TYPE)\
		-> Union[Tuple[AcsError, int], FRD]:
	"""This function calculates open loop FRD based on servo parameters, servo loop and frequency vector."""
	return spb.FRF_CalculateOpenLoopFRD(servoParameters, plant, loopType)


def FRF_CalculateClosedLoopFRD(servoParameters: SERVO_PARAMETERS, plant: FRD, loopType: FRF_LOOP_TYPE)\
		-> Union[Tuple[AcsError, int], FRD]:
	"""This function calculates closed loop FRD based on servo parameters, servo loop and frequency vector."""
	return spb.FRF_CalculateClosedLoopFRD(servoParameters, plant, loopType)


def FRF_CalculateStabilityMargins(openLoop: FRD)\
		-> Union[Tuple[AcsError, int], FRF_STABILITY_MARGINS]:
	"""The function calculates required stability margins based on the frequency response data of the open loop."""
	return spb.FRF_CalculateStabilityMargins(openLoop)


def FFT(inputParams: List[float]) -> Union[Tuple[AcsError, int], Set[Union[List[float], List[float]]]]:
	"""Function calculates fast Fourier transform."""
	return spb.FFT(inputParams)


def JitterAnalysis(inputParams: JITTER_ANALYSIS_INPUT) -> Union[Tuple[AcsError, int], JITTER_ANALYSIS_OUTPUT]:
	"""Function executes jitter analysis."""
	return spb.JitterAnalysis(inputParams)


def FRF_CrossCouplingMeasure(handle: int, inputParams: FRF_CROSS_COUPLING_INPUT)\
		-> Union[Tuple[AcsError, int], FRF_CROSS_COUPLING_OUTPUT]:
	return spb.FRF_CrossCouplingMeasure(handle, inputParams)


#def FRF_CalculateSLVRAT(inputParams: FRF_CALCULATE_SLVRAT_DATA) -> Union[Tuple[AcsError, int], float]:
#	"""The function calculates the SLVRAT parameter and returns it as float value."""
#	return spb.FRF_CalculateSLVRAT(inputParams)