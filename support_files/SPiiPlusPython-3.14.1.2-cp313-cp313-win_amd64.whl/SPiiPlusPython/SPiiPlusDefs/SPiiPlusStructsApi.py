##################################################################################################
##
# ACS Motion Control Ltd.
# Copyright © 1999 - 2024. All Rights Reserved.
##
# PROJECT			:    SPiiPlus
# SUBSYSTEM		:    SPiiPlus Python Package
# FILE				:	 SPiiPlusStructsApi.py
# VERSION			:    7.4.0.0
# OVERVIEW
# ========
##
# SPiiPlus Python Package export functions definition
##
##################################################################################################


# Generated at 27/05/2024 16:07:56

from SPiiPlusPython.SPiiPlusDefs.SPiiPlusStructs import *


class in_addr():
	def __init__(self, s_addr=0):
		self.s_addr = s_addr


class FRD():
	_struct_c_type = FRD_c

	def __init__(self, real=[], imag=[], frequencyHz=[]):
		self.real = real
		self.imag = imag
		self.frequencyHz = frequencyHz


	@staticmethod
	def __get_length(obj):
		return obj.length

	_ptr_dict = {
		'real': (np.double, float, __get_length.__func__, 1),
		'imag': (np.double, float, __get_length.__func__, 1),
		'frequencyHz': (np.double, float, __get_length.__func__, 1),
	}
	_length_entries = ['length']


class FRF_STABILITY_MARGINS():
	_struct_c_type = FRF_STABILITY_MARGINS_c

	def __init__(self, gainMarginArray=[], gainMarginArrayFrequencyHz=[], gainMarginWorst=0.0, gainMarginWorstFrequencyHz=0.0,
				phaseMarginArray=[], phaseMarginArrayFrequencyHz=[], phaseMarginWorst=0.0, phaseMarginWorstFrequencyHz=0.0,
				modulusMargin=0.0, modulusMarginFrequencyHz=0.0, bandwidth=0.0):
		self.gainMarginArray = gainMarginArray
		self.gainMarginArrayFrequencyHz = gainMarginArrayFrequencyHz
		self.gainMarginWorst = gainMarginWorst
		self.gainMarginWorstFrequencyHz = gainMarginWorstFrequencyHz
		self.phaseMarginArray = phaseMarginArray
		self.phaseMarginArrayFrequencyHz = phaseMarginArrayFrequencyHz
		self.phaseMarginWorst = phaseMarginWorst
		self.phaseMarginWorstFrequencyHz = phaseMarginWorstFrequencyHz
		self.modulusMargin = modulusMargin
		self.modulusMarginFrequencyHz = modulusMarginFrequencyHz
		self.bandwidth = bandwidth


	@staticmethod
	def __get_gainMarginArrayLength(obj):
		return obj.gainMarginArrayLength

	@staticmethod
	def __get_phaseMarginArrayLength(obj):
		return obj.phaseMarginArrayLength

	_ptr_dict = {
		'gainMarginArray': (np.double, float, __get_gainMarginArrayLength.__func__, 1),
		'gainMarginArrayFrequencyHz': (np.double, float, __get_gainMarginArrayLength.__func__, 1),
		'phaseMarginArray': (np.double, float, __get_phaseMarginArrayLength.__func__, 1),
		'phaseMarginArrayFrequencyHz': (np.double, float, __get_phaseMarginArrayLength.__func__, 1),
	}
	_length_entries = ['gainMarginArrayLength', 'phaseMarginArrayLength']


class FRF_DURATION_CALCULATION_PARAMETERS():
	_struct_c_type = FRF_DURATION_CALCULATION_PARAMETERS_c

	def __init__(self, frequencyDistributionType=0, startFreqHz=0.0, endFreqHz=0.0, freqPerDec=0, highResolutionStart=0.0,
				highResolutionFreqPerDec=0, frequencyHzResolutionForLinear=0.0):
		self.frequencyDistributionType = frequencyDistributionType
		self.startFreqHz = startFreqHz
		self.endFreqHz = endFreqHz
		self.freqPerDec = freqPerDec
		self.highResolutionStart = highResolutionStart
		self.highResolutionFreqPerDec = highResolutionFreqPerDec
		self.frequencyHzResolutionForLinear = frequencyHzResolutionForLinear


class FRF_INPUT():
	_struct_c_type = FRF_INPUT_c

	def __init__(self, axis=0, loopType=0, excitationType=0, chirpType=0, windowType=0, frequencyDistributionType=0,
				overlap=0, startFreqHz=0.0, endFreqHz=0.0, freqPerDec=0, excitationAmplitudePercentIp=0.0,
				numberOfRepetitions=0, highResolutionStart=0.0, highResolutionFreqPerDec=0, durationSec=0.0,
				userDefinedExcitationSignal=[], inRaw=[], outRaw=[], recalculate=False):
		self.axis = axis
		self.loopType = loopType
		self.excitationType = excitationType
		self.chirpType = chirpType
		self.windowType = windowType
		self.frequencyDistributionType = frequencyDistributionType
		self.overlap = overlap
		self.startFreqHz = startFreqHz
		self.endFreqHz = endFreqHz
		self.freqPerDec = freqPerDec
		self.excitationAmplitudePercentIp = excitationAmplitudePercentIp
		self.numberOfRepetitions = numberOfRepetitions
		self.highResolutionStart = highResolutionStart
		self.highResolutionFreqPerDec = highResolutionFreqPerDec
		self.durationSec = durationSec
		self.userDefinedExcitationSignal = userDefinedExcitationSignal
		self.inRaw = inRaw
		self.outRaw = outRaw
		self.recalculate = recalculate


	@staticmethod
	def __get_userDefinedExcitationSignalLength(obj):
		return obj.userDefinedExcitationSignalLength

	@staticmethod
	def __get_lengthRaw(obj):
		return obj.lengthRaw

	_ptr_dict = {
		'userDefinedExcitationSignal': (np.double, float, __get_userDefinedExcitationSignalLength.__func__, 1),
		'inRaw': (np.double, float, __get_lengthRaw.__func__, 1),
		'outRaw': (np.double, float, __get_lengthRaw.__func__, 1),
	}
	_length_entries = ['userDefinedExcitationSignalLength', 'lengthRaw']


class FRF_OUTPUT():
	_struct_c_type = FRF_OUTPUT_c

	def __init__(self, plant=[], controller=[], openLoop=[], closedLoop=[], sensitivity=[], coherence=[],
				stabilityMargins=[], loopType=0, inRaw=[], outRaw=[], excitationAmplitude=0.0, plantVelocityToPosition=[],
				coherenceVelocityToPosition=[]):
		self.plant = plant
		self.controller = controller
		self.openLoop = openLoop
		self.closedLoop = closedLoop
		self.sensitivity = sensitivity
		self.coherence = coherence
		self.stabilityMargins = stabilityMargins
		self.loopType = loopType
		self.inRaw = inRaw
		self.outRaw = outRaw
		self.excitationAmplitude = excitationAmplitude
		self.plantVelocityToPosition = plantVelocityToPosition
		self.coherenceVelocityToPosition = coherenceVelocityToPosition


	@staticmethod
	def __get_lengthRaw(obj):
		return obj.lengthRaw

	_ptr_dict = {
		'inRaw': (np.double, float, __get_lengthRaw.__func__, 1),
		'outRaw': (np.double, float, __get_lengthRaw.__func__, 1),
		'plant': (FRD_c, FRD, 1, 1),
		'controller': (FRD_c, FRD, 1, 1),
		'openLoop': (FRD_c, FRD, 1, 1),
		'closedLoop': (FRD_c, FRD, 1, 1),
		'sensitivity': (FRD_c, FRD, 1, 1),
		'coherence': (FRD_c, FRD, 1, 1),
		'stabilityMargins': (FRF_STABILITY_MARGINS_c, FRF_STABILITY_MARGINS, 1, 1),
		'plantVelocityToPosition': (FRD_c, FRD, 1, 1),
		'coherenceVelocityToPosition': (FRD_c, FRD, 1, 1),
	}
	_length_entries = ['lengthRaw']


class FILTER_ROUTING():
	_struct_c_type = FILTER_ROUTING_c

	def __init__(self, SLVNFRQ0=0.0, SLVNWID0=0.0, SLVNATT0=0.0, SLVB0NF0=0.0, SLVB0DF0=0.0, SLVB0ND0=0.0,
				SLVB0DD0=0.0, SLVB1NF0=0.0, SLVB1DF0=0.0, SLVB1ND0=0.0, SLVB1DD0=0.0, SLVNFRQ1=0.0,
				SLVNWID1=0.0, SLVNATT1=0.0, SLVB0NF1=0.0, SLVB0DF1=0.0, SLVB0ND1=0.0, SLVB0DD1=0.0,
				SLVB1NF1=0.0, SLVB1DF1=0.0, SLVB1ND1=0.0, SLVB1DD1=0.0, SLVNFRQ2=0.0, SLVNWID2=0.0,
				SLVNATT2=0.0, SLVB0NF2=0.0, SLVB0DF2=0.0, SLVB0ND2=0.0, SLVB0DD2=0.0, SLVB1NF2=0.0,
				SLVB1DF2=0.0, SLVB1ND2=0.0, SLVB1DD2=0.0, SLVNFRQ3=0.0, SLVNWID3=0.0, SLVNATT3=0.0,
				SLVB0NF3=0.0, SLVB0DF3=0.0, SLVB0ND3=0.0, SLVB0DD3=0.0, SLVB1NF3=0.0, SLVB1DF3=0.0,
				SLVB1ND3=0.0, SLVB1DD3=0.0, MFLAGS0=0, MFLAGS1=0, MFLAGS2=0, MFLAGS3=0):
		self.SLVNFRQ0 = SLVNFRQ0
		self.SLVNWID0 = SLVNWID0
		self.SLVNATT0 = SLVNATT0
		self.SLVB0NF0 = SLVB0NF0
		self.SLVB0DF0 = SLVB0DF0
		self.SLVB0ND0 = SLVB0ND0
		self.SLVB0DD0 = SLVB0DD0
		self.SLVB1NF0 = SLVB1NF0
		self.SLVB1DF0 = SLVB1DF0
		self.SLVB1ND0 = SLVB1ND0
		self.SLVB1DD0 = SLVB1DD0
		self.SLVNFRQ1 = SLVNFRQ1
		self.SLVNWID1 = SLVNWID1
		self.SLVNATT1 = SLVNATT1
		self.SLVB0NF1 = SLVB0NF1
		self.SLVB0DF1 = SLVB0DF1
		self.SLVB0ND1 = SLVB0ND1
		self.SLVB0DD1 = SLVB0DD1
		self.SLVB1NF1 = SLVB1NF1
		self.SLVB1DF1 = SLVB1DF1
		self.SLVB1ND1 = SLVB1ND1
		self.SLVB1DD1 = SLVB1DD1
		self.SLVNFRQ2 = SLVNFRQ2
		self.SLVNWID2 = SLVNWID2
		self.SLVNATT2 = SLVNATT2
		self.SLVB0NF2 = SLVB0NF2
		self.SLVB0DF2 = SLVB0DF2
		self.SLVB0ND2 = SLVB0ND2
		self.SLVB0DD2 = SLVB0DD2
		self.SLVB1NF2 = SLVB1NF2
		self.SLVB1DF2 = SLVB1DF2
		self.SLVB1ND2 = SLVB1ND2
		self.SLVB1DD2 = SLVB1DD2
		self.SLVNFRQ3 = SLVNFRQ3
		self.SLVNWID3 = SLVNWID3
		self.SLVNATT3 = SLVNATT3
		self.SLVB0NF3 = SLVB0NF3
		self.SLVB0DF3 = SLVB0DF3
		self.SLVB0ND3 = SLVB0ND3
		self.SLVB0DD3 = SLVB0DD3
		self.SLVB1NF3 = SLVB1NF3
		self.SLVB1DF3 = SLVB1DF3
		self.SLVB1ND3 = SLVB1ND3
		self.SLVB1DD3 = SLVB1DD3
		self.MFLAGS0 = MFLAGS0
		self.MFLAGS1 = MFLAGS1
		self.MFLAGS2 = MFLAGS2
		self.MFLAGS3 = MFLAGS3


class SERVO_PARAMETERS():
	_struct_c_type = SERVO_PARAMETERS_c

	def __init__(self, SLIKP=0.0, SLIKI=0.0, SLILI=0.0, SLPKP=0.0, SLPKI=0.0, SLPLI=0.0, SLVKP=0.0, SLVKI=0.0,
				SLVLI=0.0, SLVSOF=0.0, SLVSOFD=0.0, SLVNFRQ=0.0, SLVNWID=0.0, SLVNATT=0.0, SLVB0NF=0.0,
				SLVB0DF=0.0, SLVB0ND=0.0, SLVB0DD=0.0, SLVB1NF=0.0, SLVB1DF=0.0, SLVB1ND=0.0, SLVB1DD=0.0,
				XVEL=0.0, EFAC=0.0, SLVRAT=0.0, SLAFF=0.0, MFLAGS=0, MFLAGSX=0, FilterRouting=FILTER_ROUTING()):
		self.SLIKP = SLIKP
		self.SLIKI = SLIKI
		self.SLILI = SLILI
		self.SLPKP = SLPKP
		self.SLPKI = SLPKI
		self.SLPLI = SLPLI
		self.SLVKP = SLVKP
		self.SLVKI = SLVKI
		self.SLVLI = SLVLI
		self.SLVSOF = SLVSOF
		self.SLVSOFD = SLVSOFD
		self.SLVNFRQ = SLVNFRQ
		self.SLVNWID = SLVNWID
		self.SLVNATT = SLVNATT
		self.SLVB0NF = SLVB0NF
		self.SLVB0DF = SLVB0DF
		self.SLVB0ND = SLVB0ND
		self.SLVB0DD = SLVB0DD
		self.SLVB1NF = SLVB1NF
		self.SLVB1DF = SLVB1DF
		self.SLVB1ND = SLVB1ND
		self.SLVB1DD = SLVB1DD
		self.XVEL = XVEL
		self.EFAC = EFAC
		self.SLVRAT = SLVRAT
		self.SLAFF = SLAFF
		self.MFLAGS = MFLAGS
		self.MFLAGSX = MFLAGSX
		self.FilterRouting = FilterRouting


class FRF_CALCULATE_LOOP_DATA():
	_struct_c_type = FRF_CALCULATE_LOOP_DATA_c

	def __init__(self, plant=[], plantVelocityToPosition=[], servoParameters=[], dataType=0, measureLoopType=0,
				targetLoopType=0):
		self.plant = plant
		self.plantVelocityToPosition = plantVelocityToPosition
		self.servoParameters = servoParameters
		self.dataType = dataType
		self.measureLoopType = measureLoopType
		self.targetLoopType = targetLoopType


class FRF_CALCULATE_SLVRAT_DATA():
	_struct_c_type = FRF_CALCULATE_SLVRAT_DATA_c

	def __init__(self, plantVelocityToPosition=[], startFrequencyHz=0.0, endFrequencyHz=0.0):
		self.plantVelocityToPosition = plantVelocityToPosition
		self.startFrequencyHz = startFrequencyHz
		self.endFrequencyHz = endFrequencyHz


class JITTER_ANALYSIS_INPUT():
	_struct_c_type = JITTER_ANALYSIS_INPUT_c

	def __init__(self, jitter=[], samplingFrequencyHz=0, desiredFrequencyResolutionHz=0.0, jitterFrequencyBandsCumulativeAmplitudeRMSthreshold=[],
				frequencyBandsHz=[], windowType=0):
		self.jitter = jitter
		self.samplingFrequencyHz = samplingFrequencyHz
		self.desiredFrequencyResolutionHz = desiredFrequencyResolutionHz
		self.jitterFrequencyBandsCumulativeAmplitudeRMSthreshold = jitterFrequencyBandsCumulativeAmplitudeRMSthreshold
		self.frequencyBandsHz = frequencyBandsHz
		self.windowType = windowType


	@staticmethod
	def __get_jitterLength(obj):
		return obj.jitterLength

	@staticmethod
	def __get_frequencyBandsHzLength(obj):
		return obj.frequencyBandsHzLength

	_ptr_dict = {
		'jitter': (np.double, float, __get_jitterLength.__func__, 1),
		'jitterFrequencyBandsCumulativeAmplitudeRMSthreshold': (np.double, float, __get_frequencyBandsHzLength.__func__, 1),
		'frequencyBandsHz': (np.double, float, __get_frequencyBandsHzLength.__func__, 1),
	}
	_length_entries = ['jitterLength', 'frequencyBandsHzLength']


class JITTER_ANALYSIS_OUTPUT():
	_struct_c_type = JITTER_ANALYSIS_OUTPUT_c

	def __init__(self, jitterAmplitudeRMS=[], jitterCumulativeAmplitudeRMS=[], frequencyHz=[], jitterFrequencyBandsCumulativeAmplitudeRMS=[],
				frequencyBandsHz=[], jitterFrequencyBandsResultBool=0, jitterRMS=0.0, jitterAmplitudePeak2Peak=0.0):
		self.jitterAmplitudeRMS = jitterAmplitudeRMS
		self.jitterCumulativeAmplitudeRMS = jitterCumulativeAmplitudeRMS
		self.frequencyHz = frequencyHz
		self.jitterFrequencyBandsCumulativeAmplitudeRMS = jitterFrequencyBandsCumulativeAmplitudeRMS
		self.frequencyBandsHz = frequencyBandsHz
		self.jitterFrequencyBandsResultBool = jitterFrequencyBandsResultBool
		self.jitterRMS = jitterRMS
		self.jitterAmplitudePeak2Peak = jitterAmplitudePeak2Peak


	@staticmethod
	def __get_frequencyLength(obj):
		return obj.frequencyLength

	@staticmethod
	def __get_frequencyBandsHzLength(obj):
		return obj.frequencyBandsHzLength

	_ptr_dict = {
		'jitterAmplitudeRMS': (np.double, float, __get_frequencyLength.__func__, 1),
		'jitterCumulativeAmplitudeRMS': (np.double, float, __get_frequencyLength.__func__, 1),
		'frequencyHz': (np.double, float, __get_frequencyLength.__func__, 1),
		'jitterFrequencyBandsCumulativeAmplitudeRMS': (np.double, float, __get_frequencyBandsHzLength.__func__, 1),
		'frequencyBandsHz': (np.double, float, __get_frequencyBandsHzLength.__func__, 1),
	}
	_length_entries = ['frequencyLength', 'frequencyBandsHzLength']


class FRF_CROSS_COUPLING_INPUT():
	_struct_c_type = FRF_CROSS_COUPLING_INPUT_c

	def __init__(self, axes=[], crossCouplingType=0, excitationType=0, chirpType=0, windowType=0, frequencyDistributionType=0,
				overlap=0, startFreqHz=0.0, endFreqHz=0.0, freqPerDec=0, excitationAmplitudePercentIp=[],
				numberOfRepetitions=0, highResolutionStart=0.0, highResolutionFreqPerDec=0, durationSec=0.0,
				userDefinedExcitationSignal=[], customOutputName='', customOutputNode=0, customInputName='',
				customInputNode=0, customInputScale=0.0, customInputOffset=0.0):
		self.axes = axes
		self.crossCouplingType = crossCouplingType
		self.excitationType = excitationType
		self.chirpType = chirpType
		self.windowType = windowType
		self.frequencyDistributionType = frequencyDistributionType
		self.overlap = overlap
		self.startFreqHz = startFreqHz
		self.endFreqHz = endFreqHz
		self.freqPerDec = freqPerDec
		self.excitationAmplitudePercentIp = excitationAmplitudePercentIp
		self.numberOfRepetitions = numberOfRepetitions
		self.highResolutionStart = highResolutionStart
		self.highResolutionFreqPerDec = highResolutionFreqPerDec
		self.durationSec = durationSec
		self.userDefinedExcitationSignal = userDefinedExcitationSignal
		self.customOutputName = customOutputName
		self.customOutputNode = customOutputNode
		self.customInputName = customInputName
		self.customInputNode = customInputNode
		self.customInputScale = customInputScale
		self.customInputOffset = customInputOffset


	@staticmethod
	def __get_axesLength(obj):
		return obj.axesLength

	@staticmethod
	def __get_userDefinedExcitationSignalLength(obj):
		return obj.userDefinedExcitationSignalLength

	_ptr_dict = {
		'axes': (np.int32, int, __get_axesLength.__func__, 1),
		'excitationAmplitudePercentIp': (np.double, float, __get_axesLength.__func__, 1),
		'userDefinedExcitationSignal': (np.double, float, __get_userDefinedExcitationSignalLength.__func__, 1),
	}
	_length_entries = ['axesLength', 'userDefinedExcitationSignalLength']


class FRF_CROSS_COUPLING_OUTPUT():
	_struct_c_type = FRF_CROSS_COUPLING_OUTPUT_c

	def __init__(self, plant=[], controller=[], characteristicPolynomial=[], closedLoop=[], sensitivity=[],
				coherencePS=[], coherenceS=[], RGA=[], stabilityMargins=[], crossCouplingType=0,
				excitationAmplitude=[]):
		self.plant = plant
		self.controller = controller
		self.characteristicPolynomial = characteristicPolynomial
		self.closedLoop = closedLoop
		self.sensitivity = sensitivity
		self.coherencePS = coherencePS
		self.coherenceS = coherenceS
		self.RGA = RGA
		self.stabilityMargins = stabilityMargins
		self.crossCouplingType = crossCouplingType
		self.excitationAmplitude = excitationAmplitude


	@staticmethod
	def __get_matrixSize(obj):
		return obj.matrixSize

	_ptr_dict = {
		'plant': (FRD_c, FRD, __get_matrixSize.__func__, 2),
		'controller': (FRD_c, FRD, __get_matrixSize.__func__, 2),
		'characteristicPolynomial': (FRD_c, FRD, 1, 1),
		'closedLoop': (FRD_c, FRD, __get_matrixSize.__func__, 2),
		'sensitivity': (FRD_c, FRD, __get_matrixSize.__func__, 2),
		'RGA': (FRD_c, FRD, __get_matrixSize.__func__, 2),
		'coherencePS': (FRD_c, FRD, __get_matrixSize.__func__, 2),
		'coherenceS': (FRD_c, FRD, __get_matrixSize.__func__, 2),
		'stabilityMargins': (FRF_STABILITY_MARGINS_c, FRF_STABILITY_MARGINS, 1, 1),
		'excitationAmplitude': (np.double, float, __get_matrixSize.__func__, 1),
	}
	_length_entries = ['matrixSize']




class ACSC_WAITBLOCK(ACSCtypesStructure):
	_fields_ = [('Event', ct.c_void_p),
				('Ret', ct.c_int)]


class WAITBLOCK(ACSCtypesStructure):
	_fields_ = [('Event', ct.c_void_p),
				('Ret', ct.c_int)]
class ACSC_PCI_SLOT():
	_struct_c_type = ACSC_PCI_SLOT_c

	def __init__(self, BusNumber=0, SlotNumber=0, Function=0):
		self.BusNumber = BusNumber
		self.SlotNumber = SlotNumber
		self.Function = Function


class PCI_SLOT():
	_struct_c_type = PCI_SLOT_c

	def __init__(self, BusNumber=0, SlotNumber=0, Function=0):
		self.BusNumber = BusNumber
		self.SlotNumber = SlotNumber
		self.Function = Function


class ACSC_CONNECTION_DESC():
	_struct_c_type = ACSC_CONNECTION_DESC_c

	def __init__(self, Application='', Handle=0, ProcessId=0):
		self.Application = Application
		self.Handle = Handle
		self.ProcessId = ProcessId


class ACSC_CONNECTION_INFO():
	_struct_c_type = ACSC_CONNECTION_INFO_c

	def __init__(self, Type=0, SerialPort=0, SerialBaudRate=0, PCISlot=0, EthernetProtocol=0, EthernetIP='',
				EthernetPort=0):
		self.Type = Type
		self.SerialPort = SerialPort
		self.SerialBaudRate = SerialBaudRate
		self.PCISlot = PCISlot
		self.EthernetProtocol = EthernetProtocol
		self.EthernetIP = EthernetIP
		self.EthernetPort = EthernetPort


class ACSC_APPSL_STRING():
	_struct_c_type = ACSC_APPSL_STRING_c

	def __init__(self, length=0, string='', _struct_c=None):
		self._struct_c = _struct_c
		self.length = length
		self.string = string


class ACSC_APPSL_SECTION():
	_struct_c_type = ACSC_APPSL_SECTION_c

	def __init__(self, type=0, filename=ACSC_APPSL_STRING(), description=ACSC_APPSL_STRING(), size=0,
				offset=0, CRC=0, inuse=0, error=0, data='', _struct_c=None):
		self._struct_c = _struct_c
		self.type = type
		self.filename = filename
		self.description = description
		self.size = size
		self.offset = offset
		self.CRC = CRC
		self.inuse = inuse
		self.error = error
		self.data = data


class ACSC_APPSL_ATTRIBUTE():
	_struct_c_type = ACSC_APPSL_ATTRIBUTE_c

	def __init__(self, key=ACSC_APPSL_STRING(), value=ACSC_APPSL_STRING(), _struct_c=None):
		self._struct_c = _struct_c
		self.key = key
		self.value = value


class ACSC_APPSL_INFO():
	_struct_c_type = ACSC_APPSL_INFO_c

	def __init__(self, filename=ACSC_APPSL_STRING(), description=ACSC_APPSL_STRING(), isNewFile=0, ErrCode=0,
				attributes_num=0, attributes=[], sections_num=0, sections=[], _struct_c=None):
		self._struct_c = _struct_c
		self.filename = filename
		self.description = description
		self.isNewFile = isNewFile
		self.ErrCode = ErrCode
		self.attributes_num = attributes_num
		self.attributes = attributes
		self.sections_num = sections_num
		self.sections = sections


	@staticmethod
	def __get_attributes_num(obj):
		return obj.attributes_num

	@staticmethod
	def __get_sections_num(obj):
		return obj.sections_num

	_ptr_dict = {
		'attributes': (ACSC_APPSL_ATTRIBUTE_c, ACSC_APPSL_ATTRIBUTE, __get_attributes_num.__func__, 1),
		'sections': (ACSC_APPSL_SECTION_c, ACSC_APPSL_SECTION, __get_sections_num.__func__, 1),
	}
	_length_entries = ['attributes_num', 'sections_num']


class ACSC_HISTORYBUFFER():
	_struct_c_type = ACSC_HISTORYBUFFER_c

	def __init__(self, Max=0, Cur=0, Ring=0, Buf=''):
		self.Max = Max
		self.Cur = Cur
		self.Ring = Ring
		self.Buf = Buf


class ACSC_CONTROLLER_INFO():
	_struct_c_type = ACSC_CONTROLLER_INFO_c

	def __init__(self, IpAddress=in_addr(), SerialNumber='', PartNumber='', Version=''):
		self.IpAddress = IpAddress
		self.SerialNumber = SerialNumber
		self.PartNumber = PartNumber
		self.Version = Version


class AXMASK_EXT():
	_struct_c_type = AXMASK_EXT_c

	def __init__(self, AXMASK64=0, AXMASK128=0, Reserved1=0, Reserved2=0):
		self.AXMASK64 = AXMASK64
		self.AXMASK128 = AXMASK128
		self.Reserved1 = Reserved1
		self.Reserved2 = Reserved2


